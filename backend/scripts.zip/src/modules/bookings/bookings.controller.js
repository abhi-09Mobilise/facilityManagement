// Bookings CRUD.
//
//   POST   /api/bookings            - employee/approver creates a booking
//   GET    /api/bookings            - list (own bookings by default; ?scope=tenant
//                                     for admins; ?scope=team for dept managers)
//   GET    /api/bookings/check      - capacity / conflict pre-flight
//   GET    /api/bookings/:id        - one with guests + meals + approvals
//   POST   /api/bookings/:id/cancel - booker cancels
//
// Capacity model (migration 021):
//   - facilities.shared_booking = 0 (default): exclusive. Any overlapping
//     pending/approved/completed booking blocks the slot.
//   - facilities.shared_booking = 1: multiple bookings can co-exist as long
//     as SUM(attendee_count) over any overlapping minute stays <= capacity.
//
// Race-safety: bookings.create runs the post-INSERT capacity SUM with
// FOR SHARE inside the same transaction. InnoDB's gap locks on the
// (facility_id, status, start_at, end_at) range force concurrent inserts
// to serialise: the second tx either sees the first row in its sum (and
// rolls back if over capacity) or blocks until the first commits.

const { query, withTransaction } = require('../../db/pool');
const { ok, created, fail, notFound } = require('../../utils/response');
const asyncHandler = require('../../utils/asyncHandler');
const { intOrNull } = require('../../utils/tenantScope');
const { materializeChain, resolveRecipients } = require('./chainMaterializer');
const { issueToken } = require('../../utils/approvalActionTokens');
const bookingActionTokens = require('../../utils/bookingActionTokens');
const checkinCode = require('../../utils/checkinCode'); // M15 QR check-in code
const slotOverrides = require('../facilities/slotOverrides.controller'); // F01 effectiveCapacity
const mailer = require('../../utils/mailer');

const VALID_REPEAT = ['none', 'daily', 'weekly_wed', 'custom'];

function tenantScopeWhere(req, alias = 'b') {
  if (req.user.role === 'super_admin') {
    const tid = intOrNull(req.query.tenant_id);
    return tid !== null
      ? { sql: ` AND ${alias}.tenant_id = ?`, params: [tid] }
      : { sql: '', params: [] };
  }
  return { sql: ` AND ${alias}.tenant_id = ?`, params: [req.user.tenant_id] };
}

async function loadBooker(userId) {
  const rows = await query(
    'SELECT id, tenant_id, department_id, name, lname, email ' +
    '  FROM `users` WHERE id = ? AND trash = 0 LIMIT 1',
    [userId]
  );
  return rows[0] || null;
}

async function loadFacility(facilityId) {
  const rows = await query(
    'SELECT id, tenant_id, site_id, name, type, capacity, offline_capacity, ' +
    '       min_advance_minutes, max_advance_days, max_per_user_per_day, ' +
    '       max_per_user_per_week, max_per_user_per_month, ' +
    '       requires_approval, shared_booking, status, trash ' +
    '  FROM `facilities` WHERE id = ? LIMIT 1',
    [facilityId]
  );
  return rows[0] || null;
}

// ---- F? Advance booking rules ----------------------------------------
//
// Five optional rules live on the facility row (all NULL = unlimited):
//
//   min_advance_minutes        - reject if (start_at - now) < N minutes
//   max_advance_days           - reject if start_at is more than N days from now
//   max_per_user_per_day       - cap active bookings per booker per calendar day
//   max_per_user_per_week      - cap active bookings per booker per Mon-Sun week
//   max_per_user_per_month     - cap active bookings per booker per calendar month
//
// Super_admin + tenant_admin bypass everything (admin override).
// Cancelled / rejected bookings are excluded from the count - the user
// confirmed they should "free up the slot".
// Week boundary = Monday 00:00 -> next Monday 00:00 (user pick).
//
// Returns { ok: true } or { ok: false, code, msg, status }.
async function checkAdvanceRules(facility, startAt, userId, userRole, opts = {}) {
  // Admin bypass.
  if (userRole === 'super_admin' || userRole === 'tenant_admin') {
    return { ok: true };
  }

  const startMs = new Date(startAt).getTime();
  const nowMs   = Date.now();

  // Lead time guard.
  const minAdv = Number(facility.min_advance_minutes);
  if (Number.isFinite(minAdv) && minAdv > 0) {
    const leadMin = (startMs - nowMs) / 60000;
    if (leadMin < minAdv) {
      return {
        ok: false,
        code: 'MIN_ADVANCE',
        status: 422,
        msg: `This facility requires booking at least ${minAdv} minute(s) in advance.`,
      };
    }
  }
  // Max-advance guard.
  const maxDays = Number(facility.max_advance_days);
  if (Number.isFinite(maxDays) && maxDays > 0) {
    const leadDays = (startMs - nowMs) / 86400000;
    if (leadDays > maxDays) {
      return {
        ok: false,
        code: 'MAX_ADVANCE',
        status: 422,
        msg: `This facility can't be booked more than ${maxDays} day(s) in advance.`,
      };
    }
  }

  // Per-user count limits - bail early if none configured.
  const lDay   = Number(facility.max_per_user_per_day);
  const lWeek  = Number(facility.max_per_user_per_week);
  const lMonth = Number(facility.max_per_user_per_month);
  const wantDay   = Number.isFinite(lDay)   && lDay   > 0;
  const wantWeek  = Number.isFinite(lWeek)  && lWeek  > 0;
  const wantMonth = Number.isFinite(lMonth) && lMonth > 0;
  if (!wantDay && !wantWeek && !wantMonth) return { ok: true };

  // Compute the three windows (local-server time; mysql stores as DATETIME
  // without timezone). All boundaries are anchored on the booking's
  // start_at date so the rule reads naturally as "per booking-day".
  const d = new Date(startAt);
  // Day = midnight -> next midnight of start_at's date.
  const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0);
  const dayEnd   = new Date(dayStart.getTime() + 86400000);
  // Week = Monday 00:00 -> next Monday 00:00. JS Date.getDay() returns 0=Sun..6=Sat.
  const dow = d.getDay();
  const mondayOffset = (dow === 0 ? -6 : 1 - dow); // sun -> back 6, mon -> 0, tue -> back 1...
  const weekStart = new Date(d.getFullYear(), d.getMonth(), d.getDate() + mondayOffset, 0, 0, 0);
  const weekEnd   = new Date(weekStart.getTime() + 7 * 86400000);
  // Month = 1st of month 00:00 -> 1st of next month 00:00.
  const monthStart = new Date(d.getFullYear(), d.getMonth(),     1, 0, 0, 0);
  const monthEnd   = new Date(d.getFullYear(), d.getMonth() + 1, 1, 0, 0, 0);

  const fmt = (dt) => {
    const pad = (n) => String(n).padStart(2, '0');
    return `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())} ${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`;
  };

  // Helper - count this user's active bookings whose start_at lies in [s, e).
  // Cancelled / rejected excluded (user confirmed cancelled frees the slot).
  // opts.excludeBookingId lets reschedule exclude the booking being moved.
  async function countIn(s, e) {
    const params = [facility.id, userId, fmt(s), fmt(e)];
    let sql =
      'SELECT COUNT(*) AS cnt FROM `bookings` ' +
      ' WHERE facility_id = ? AND user_id = ? AND trash = 0 ' +
      "   AND status IN ('pending', 'approved') " +
      '   AND start_at >= ? AND start_at < ? ';
    if (opts.excludeBookingId) {
      sql += 'AND id <> ? ';
      params.push(opts.excludeBookingId);
    }
    const r = await query(sql, params);
    return Number(r[0]?.cnt || 0);
  }

  if (wantDay) {
    const used = await countIn(dayStart, dayEnd);
    // We're about to add ONE more booking; reject when used+1 would exceed cap.
    if (used + 1 > lDay) {
      return {
        ok: false,
        code: 'CAP_DAY',
        status: 422,
        msg: `You've reached the daily limit of ${lDay} booking(s) for this facility.`,
      };
    }
  }
  if (wantWeek) {
    const used = await countIn(weekStart, weekEnd);
    if (used + 1 > lWeek) {
      return {
        ok: false,
        code: 'CAP_WEEK',
        status: 422,
        msg: `You've reached the weekly limit of ${lWeek} booking(s) for this facility (week starts Monday).`,
      };
    }
  }
  if (wantMonth) {
    const used = await countIn(monthStart, monthEnd);
    if (used + 1 > lMonth) {
      return {
        ok: false,
        code: 'CAP_MONTH',
        status: 422,
        msg: `You've reached the monthly limit of ${lMonth} booking(s) for this facility.`,
      };
    }
  }
  return { ok: true };
}

/**
 * Sum attendee_count of all live bookings that overlap [startAt, endAt) for
 * a facility. Optionally excludes one booking id (used when probing a slot
 * during an edit — we don't actually edit today, but the param is here so
 * the helper is reusable).
 *
 * runner: either the global `query` helper (read-only probes outside a txn)
 * or a connection's `execute` (inside a txn). When runner is a conn we want
 * FOR SHARE so the txn gap-locks the window.
 */
async function sumOverlapAttendees(runner, facilityId, startAt, endAt, opts = {}) {
  const { excludeBookingId = null, forShare = false } = opts;
  const params = [facilityId, endAt, startAt];
  let sql =
    'SELECT COALESCE(SUM(attendee_count), 0) AS total ' +
    '  FROM `bookings` ' +
    " WHERE facility_id = ? AND trash = 0 " +
    "   AND status IN ('pending', 'approved', 'completed') " +
    '   AND start_at < ? AND end_at > ? ';
  if (excludeBookingId) { sql += 'AND id <> ? '; params.push(excludeBookingId); }
  if (forShare) sql += 'FOR SHARE';

  // Two callers: `query()` returns rows directly; `conn.execute()` returns
  // [rows, fields]. Normalise.
  const result = await runner(sql, params);
  const rows = Array.isArray(result) && Array.isArray(result[0]) ? result[0] : result;
  return Number(rows[0]?.total || 0);
}

/**
 * Computes availability for a candidate slot.
 *
 * For exclusive facilities: same semantics as the old hasConflict — any
 * overlap fails.
 * For shared facilities: succeeds as long as
 * existing_attendees + needAttendees <= capacity.
 *
 * Returns { ok, mode, capacity, seatsTaken, seatsRemaining }.
 */
async function checkAvailability(facility, startAt, endAt, needAttendees = 1, opts = {}) {
  // F01 - resolve effective capacity from per-slot overrides if any match.
  const eff = await slotOverrides.effectiveCapacity(facility.id, startAt, endAt);
 
  // Per-slot override wins; otherwise fall back to (facility.capacity - offline).
  // offline_capacity is seats held back from the system (VIPs, walk-ins,
  // maintenance, etc) — never bookable through the app.
  const baseCap = Number(facility.capacity) || 0;
  const offCap  = Number(facility.offline_capacity) || 0;
  const onlineCap = Math.max(0, baseCap - offCap);
  const capacity = Math.max(0, Number(eff.matched ? eff.max : onlineCap) || 0);
  const minAttendees = eff.matched ? Number(eff.min) : 1;
  const mode = facility.shared_booking ? 'shared' : 'exclusive';
  const taken = await sumOverlapAttendees(query, facility.id, startAt, endAt, opts);

  // Below-min party for this slot is rejected regardless of capacity.
  if (needAttendees < minAttendees) {
    return {
      ok: false,
      mode, capacity,
      seatsTaken: taken,
      seatsRemaining: Math.max(0, capacity - taken),
      minAttendees,
      reason: 'BELOW_MIN',
    };
  }

  if (mode === 'exclusive') {
    return {
      ok: taken === 0,
      mode, capacity,
      seatsTaken: taken,
      seatsRemaining: taken === 0 ? capacity : 0,
      minAttendees,
    };
  }
  const remaining = Math.max(0, capacity - taken);
  return {
    ok: (taken + needAttendees) <= capacity,
    mode, capacity,
    seatsTaken: taken,
    seatsRemaining: remaining,
    minAttendees,
  };
}

// ---------- operating-hours guard (M? — booking window) ---------------
//
// Enforces that a booking falls inside the facility's configured opening
// hours. All comparisons run in SQL against the stored start_at/end_at (via
// DAYOFWEEK/TIME), so they're immune to the Node process timezone.
//
// Rules:
//   - facility has NO operating-hours rows  -> unrestricted (allow).
//   - no row for the booking's weekday      -> facility closed that day (reject).
//   - row exists and booking is same-day    -> require open <= start, end <= close.
//   - row exists but booking spans days      -> can't express with daily hours;
//                                               allow (don't falsely reject).
// day_of_week is 0=Sun..6=Sat; MySQL DAYOFWEEK() is 1=Sun..7=Sat, hence -1.
async function checkOperatingHours(facilityId, startAt, endAt) {
  const rows = await query(
    'SELECT open_time, close_time, slot_minutes, ' +
    '       (DATE(?) = DATE(?)) AS same_day, ' +
    '       (TIME(?) >= open_time AND TIME(?) <= close_time) AS within ' +
    '  FROM `facility_operating_hours` ' +
    ' WHERE facility_id = ? AND day_of_week = DAYOFWEEK(?) - 1 LIMIT 1',
    [startAt, endAt, startAt, endAt, facilityId, startAt]
  );
  if (rows.length === 0) {
    const any = await query(
      'SELECT COUNT(*) AS c FROM `facility_operating_hours` WHERE facility_id = ?',
      [facilityId]
    );
    if (Number(any[0].c) > 0) {
      return { ok: false, msg: 'This facility is closed on the selected day.' };
    }
    return { ok: true }; // no hours configured -> unrestricted
  }
  const r = rows[0];
  if (Number(r.same_day) === 1 && Number(r.within) !== 1) {
    const o = String(r.open_time).slice(0, 5);
    const c = String(r.close_time).slice(0, 5);
    return { ok: false, msg: `This facility is open ${o}–${c} on that day. Pick a time within opening hours.` };
  }
  // BUG-09 fix: enforce slot-grid alignment. If the facility uses 30-min
  // slots then both start and end minutes must land on a boundary measured
  // from the configured open_time (e.g. 09:00 → 09:30, 10:00 …). Rejects
  // off-grid picks like 10:07–10:19 that the frontend would never offer
  // but a direct API client could still POST.
  const slotMin = Number(r.slot_minutes) || 0;
  if (slotMin > 0 && Number(r.same_day) === 1) {
    const openMins = timeToMinutes(String(r.open_time));
    const startMins = timeToMinutes(timeOfIsoDt(startAt));
    const endMins = timeToMinutes(timeOfIsoDt(endAt));
    if (startMins === null || endMins === null || openMins === null) {
      return { ok: false, msg: 'Invalid start/end time format.' };
    }
    const startOff = (startMins - openMins) % slotMin;
    const endOff = (endMins - openMins) % slotMin;
    if (startOff !== 0 || endOff !== 0) {
      return {
        ok: false,
        msg: `Booking times must align to the ${slotMin}-minute slot grid for this facility.`,
      };
    }
  }
  return { ok: true };
}

// Helpers for slot-grid alignment check above.
function timeToMinutes(hhmmss) {
  if (!hhmmss) return null;
  const parts = String(hhmmss).split(':');
  if (parts.length < 2) return null;
  const h = Number(parts[0]);
  const m = Number(parts[1]);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return null;
  return h * 60 + m;
}

function timeOfIsoDt(dt) {
  // Accepts 'YYYY-MM-DD HH:MM:SS' or 'YYYY-MM-DDTHH:MM:SS' and returns 'HH:MM'.
  if (!dt) return null;
  const s = String(dt);
  const sep = s.indexOf('T') >= 0 ? 'T' : ' ';
  const timePart = s.split(sep)[1] || '';
  return timePart.slice(0, 5) || null;
}

// ---------- check ----------------------------------------------------
//
// GET /api/bookings/check?facility_id=...&start_at=...&end_at=...&attendees=N
//
// Returns:
//   { conflict, mode, capacity, seats_taken, seats_remaining }
//
// `conflict` is preserved for the existing UI: true if this candidate
// booking can't fit. The richer fields let the UI show "5 of 12 seats
// taken" for shared facilities.

exports.check = asyncHandler(async function (req, res) {
  const facilityId = intOrNull(req.query.facility_id);
  const startAt = req.query.start_at;
  const endAt   = req.query.end_at;
  const need = Math.max(1, intOrNull(req.query.attendees) || 1);

  if (!facilityId)        return fail(res, 'facility_id is required', 422);
  if (!startAt || !endAt) return fail(res, 'start_at and end_at are required (YYYY-MM-DD HH:MM:SS)', 422);
  if (startAt >= endAt)   return fail(res, 'end_at must be after start_at', 422);

  const facility = await loadFacility(facilityId);
  if (!facility || facility.trash) return fail(res, 'Facility not found', 404);
  if (req.user.role !== 'super_admin' && facility.tenant_id !== req.user.tenant_id) {
    return fail(res, 'Forbidden', 403);
  }

  const a = await checkAvailability(facility, startAt, endAt, need);
  console.log(a)
  // F09 - which desk ids are already taken in this exact window. Used by the
  // booker UI to grey out unavailable chairs in the layout picker.
  //
  // Reads from the `booking_desks` junction table (one row per claimed desk).
  // Pre-migration bookings are mirrored into the junction by migration 053's
  // backfill, so this query covers both legacy and new rows.
  const occupiedRows = await query(
    'SELECT DISTINCT bd.desk_id ' +
    '  FROM `booking_desks` bd ' +
    '  INNER JOIN `bookings` b ON b.id = bd.booking_id ' +
    ' WHERE b.facility_id = ? AND b.trash = 0 ' +
    "   AND b.status IN ('pending', 'approved', 'completed') " +
    '   AND b.start_at < ? AND b.end_at > ?',
    [facilityId, endAt, startAt]
  );
  const occupiedSet = new Set();
  for (const r of occupiedRows) {
    if (r.desk_id) occupiedSet.add(String(r.desk_id).trim());
  }
  const occupied_desks = Array.from(occupiedSet);

  return ok(res, {
    conflict: !a.ok,
    mode: a.mode,
    capacity: a.capacity,
    seats_taken: a.seatsTaken,
    seats_remaining: a.seatsRemaining,
    min_attendees: a.minAttendees || 1,
    reason: a.reason || null,
    occupied_desks,
  });
});

// ---------- day availability (BUG-28 batch) ----------------------------
//
// GET /api/bookings/day?facility_id=X&date=YYYY-MM-DD&attendees=N
//
// Returns per-slot availability for every slot on the requested day in a
// SINGLE round-trip. Replaces the old pattern of firing N parallel
// /bookings/check calls (one per slot) that was flagged as an N+1 by the
// QA report.
//
// Shape:
//   {
//     facility_id, date,
//     mode: 'exclusive' | 'shared',
//     capacity: number,
//     slots: [{ start: 'HH:MM', end: 'HH:MM', conflict, seats_taken,
//               seats_remaining }, ...]
//   }
exports.dayAvailability = asyncHandler(async function (req, res) {
  const facilityId = intOrNull(req.query.facility_id);
  const date = String(req.query.date || '').trim();
  const attendees = Math.max(1, intOrNull(req.query.attendees) || 1);
  if (facilityId === null) return fail(res, 'facility_id is required', 422);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return fail(res, 'date must be YYYY-MM-DD', 422);

  // Facility metadata.
  const facRows = await query(
    'SELECT id, capacity, shared_booking FROM `facilities` WHERE id = ? AND trash = 0 AND status = 1 LIMIT 1',
    [facilityId]
  );
  if (facRows.length === 0) return notFound(res, 'Facility not found');
  const facility = facRows[0];
  const mode = facility.shared_booking ? 'shared' : 'exclusive';
  const capacity = Number(facility.capacity) || 0;

  // Operating hours for the requested weekday.
  const hoursRows = await query(
    'SELECT open_time, close_time, slot_minutes ' +
    '  FROM `facility_operating_hours` ' +
    ' WHERE facility_id = ? AND day_of_week = DAYOFWEEK(?) - 1 LIMIT 1',
    [facilityId, date]
  );
  if (hoursRows.length === 0) {
    return ok(res, { facility_id: facilityId, date, mode, capacity, slots: [], closed: true });
  }
  const h = hoursRows[0];
  const slotMin = Math.max(5, Number(h.slot_minutes) || 30);
  const openMin = _toMinutes(String(h.open_time));
  const closeMin = _toMinutes(String(h.close_time));
  if (openMin == null || closeMin == null || closeMin <= openMin) {
    return ok(res, { facility_id: facilityId, date, mode, capacity, slots: [], closed: true });
  }

  // All active bookings for this facility on this date — one query.
  const dayStart = `${date} 00:00:00`;
  const dayEnd = `${date} 23:59:59`;
  const bookingRows = await query(
    'SELECT start_at, end_at, attendee_count ' +
    '  FROM `bookings` ' +
    ' WHERE facility_id = ? AND trash = 0 ' +
    "   AND status IN ('pending', 'approved', 'completed') " +
    '   AND start_at < ? AND end_at > ?',
    [facilityId, dayEnd, dayStart]
  );

  // Precompute each booking's start/end in minutes-since-midnight so slot
  // overlap checks stay cheap in the loop below.
  const liveBookings = bookingRows
    .map((b) => ({
      startMin: _dtToMinutesOnDate(b.start_at, date),
      endMin: _dtToMinutesOnDate(b.end_at, date),
      seats: Math.max(1, Number(b.attendee_count) || 1),
    }))
    .filter((b) => b.startMin !== null && b.endMin !== null);

  // Walk the open window one slot at a time.
  const slots = [];
  for (let m = openMin; m + slotMin <= closeMin; m += slotMin) {
    const slotStart = m;
    const slotEnd = m + slotMin;
    let seatsTaken = 0;
    for (const lb of liveBookings) {
      if (lb.startMin < slotEnd && lb.endMin > slotStart) {
        seatsTaken += lb.seats;
      }
    }
    const seatsRemaining = Math.max(0, capacity - seatsTaken);
    let conflict;
    if (mode === 'shared') {
      conflict = capacity > 0 && (seatsTaken + attendees) > capacity;
    } else {
      conflict = seatsTaken > 0;
    }
    slots.push({
      start: _toHHMM(slotStart),
      end: _toHHMM(slotEnd),
      conflict,
      seats_taken: seatsTaken,
      seats_remaining: seatsRemaining,
    });
  }

  return ok(res, { facility_id: facilityId, date, mode, capacity, slots, closed: false });
});

// Local helpers for the batch endpoint — kept adjacent to the only caller
// so the main controller keeps its tiny-helper discipline.
function _toMinutes(hhmmss) {
  if (!hhmmss) return null;
  const parts = String(hhmmss).split(':');
  if (parts.length < 2) return null;
  const h = Number(parts[0]);
  const m = Number(parts[1]);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return null;
  return h * 60 + m;
}

function _toHHMM(min) {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function _dtToMinutesOnDate(dt, date) {
  if (!dt) return null;
  const s = String(dt);
  // "YYYY-MM-DD HH:MM:SS" or ISO with T
  const sep = s.indexOf('T') >= 0 ? 'T' : ' ';
  const [day, timePart] = s.split(sep);
  if (!day || !timePart) return null;
  // Bookings that span days (overnight) are clipped to the requested date:
  //   starts before the day → 0 min
  //   ends after the day    → 24*60 min
  if (day < date) return 0;
  if (day > date) return 24 * 60;
  return _toMinutes(timePart);
}

// ---------- create ----------------------------------------------------

exports.create = asyncHandler(async function (req, res) {
  const b = req.body || {};
  const facilityId = intOrNull(b.facility_id);
  const startAt = b.start_at;
  const endAt   = b.end_at;

  if (!facilityId)        return fail(res, 'facility_id is required', 422);
  if (!startAt || !endAt) return fail(res, 'start_at and end_at are required (YYYY-MM-DD HH:MM:SS)', 422);
  if (startAt >= endAt)   return fail(res, 'end_at must be after start_at', 422);
  // Reject bookings that start in the past. Compared in SQL (NOW()) so it's
  // immune to the Node process timezone.
  const pastCheck = await query('SELECT (? < NOW()) AS in_past', [startAt]);
  if (Number(pastCheck[0].in_past) === 1) {
    return fail(res, 'Start time must be in the future.', 422);
  }
  if (b.repeat_type && !VALID_REPEAT.includes(b.repeat_type)) {
    return fail(res, 'repeat_type must be one of: ' + VALID_REPEAT.join(', '), 422);
  }
  // Title is required — matches the frontend `required` flag on the booking
  // form. Server enforces independently so an API client can't bypass.
  const titleStr = (b.title || '').toString().trim();
  if (!titleStr) return fail(res, 'Title is required', 422);
  if (titleStr.length > 180) return fail(res, 'Title is too long (max 180 chars)', 422);

  const facility = await loadFacility(facilityId);
  if (!facility || facility.trash) return fail(res, 'Facility not found', 404);
  if (!facility.status)            return fail(res, 'Facility is inactive', 422);

  const booker = await loadBooker(req.user.id);
  if (!booker) return fail(res, 'Booker not found', 404);
  if (booker.tenant_id !== facility.tenant_id) {
    return fail(res, 'Forbidden', 403);
  }

  // Advance-booking rules (lead time, max horizon, per-user caps).
  // Admins bypass; cancelled bookings excluded from caps.
  const advCheck = await checkAdvanceRules(facility, startAt, req.user.id, req.user.role);
  if (!advCheck.ok) return fail(res, advCheck.msg, advCheck.status);

  // Booking window: must fall inside the facility's operating hours.
  const hoursCheck = await checkOperatingHours(facilityId, startAt, endAt);
  if (!hoursCheck.ok) return fail(res, hoursCheck.msg, 422);

  const guests = Array.isArray(b.guests) ? b.guests.filter(
    (g) => g && (g.email || g.fname || g.lname || g.contact_no || g.contactNo)
  ) : [];
  const attendeeCount = 1 + guests.length;

  // Cheap UX guard - reject up front when the booker's own count alone
  // exceeds capacity. The real check happens inside the txn below.
  // Friendly upfront guard - compare against the BOOKABLE cap, not the
  // raw total. offline_capacity is reserved outside the system.
  const onlineCap = Math.max(0, (Number(facility.capacity) || 0) - (Number(facility.offline_capacity) || 0));
  if (onlineCap > 0 && attendeeCount > onlineCap) {
    return fail(
      res,
      `This facility has ${onlineCap} bookable seat(s). You are trying to book ${attendeeCount} (you + ${guests.length} guests).`,
      409
    );
  }

  // Pre-flight (outside txn) to give a friendly error fast when the slot
  // is obviously full. The post-INSERT check inside the txn is the real
  // race-safe verdict.
  const pre = await checkAvailability(facility, startAt, endAt, attendeeCount);
  if (!pre.ok) {
    if (pre.reason === 'BELOW_MIN') {
      return fail(res, `This slot needs at least ${pre.minAttendees} attendee(s) - you've only added ${attendeeCount}.`, 422);
    }
    if (pre.mode === 'exclusive') {
      return fail(res, 'That slot is already booked. Pick another time.', 409);
    }
    return fail(
      res,
      `Only ${pre.seatsRemaining} seat(s) left in that slot - your booking needs ${attendeeCount}.`,
      409
    );
  }

  const mealTimeIds = Array.isArray(b.meal_time_ids)
    ? b.meal_time_ids.map(intOrNull).filter((x) => x !== null)
    : [];

  // F06 - pantry orders. Body shape: [{ menu_item_id: 12, quantity: 2 }, ...]
  // Validation happens inside the txn (FK constraint plus an explicit check
  // that every menu_item_id belongs to a pantry linked to this facility).
  const pantryOrders = Array.isArray(b.pantry_orders)
    ? b.pantry_orders
        .map((o) => ({ menu_item_id: intOrNull(o && o.menu_item_id), quantity: Math.max(1, Number((o && o.quantity) || 1)) }))
        .filter((o) => o.menu_item_id !== null)
    : [];

  // department_id is always pulled from the booker, never trusted from the
  // client. Lets manager reports group "bookings per department" reliably.
  const departmentId = booker.department_id || null;

  // M15 - mint the arrival check-in code now so it's stamped on the row at
  // create (emailed later in the confirmation). Unique across all bookings;
  // the public /checkin page resolves a booking from this code alone.
  const checkinCodeValue = await checkinCode.generateUnique(query);

  let txResult;
  try {
    txResult = await withTransaction(async function (conn) {
      // Channel: tag the booking with which surface created it so the
      // SpaceDesk "Booking channel" dashboard tile can aggregate by source.
      // Default = 'portal' (this endpoint IS the web portal). Future mobile
      // / tablet / QR-walk-in endpoints should pass their own channel value.
      const VALID_CHANNELS = ['portal', 'app', 'qr', 'tablet'];
      const bookingChannel = VALID_CHANNELS.includes(b.channel) ? b.channel : 'portal';

      // F09 — desk IDs now go into the `booking_desks` junction table, one
      // row per desk. `bookings.desk_id` is kept NULL on new rows so the
      // VARCHAR(64) column can never overflow regardless of how many desks
      // the booker claims. See migration 053_booking_desks_junction.sql.
      const deskIdList = b.desk_id
        ? String(b.desk_id).split(',').map((s) => s.trim()).filter(Boolean)
        : [];

      const [r] = await conn.execute(
        'INSERT INTO `bookings` ' +
        '   (tenant_id, facility_id, desk_id, user_id, department_id, title, start_at, end_at, ' +
        '    repeat_type, status, channel, checkin_code, remarks, dont_disturb, attendee_count) ' +
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?)",
        [
          booker.tenant_id, facilityId,
          // Always NULL from this release onwards — junction table is the
          // source of truth. Column kept nullable for backward compat only.
          null,
          booker.id, departmentId,
          titleStr, startAt, endAt,
          b.repeat_type || 'none',
          bookingChannel,
          checkinCodeValue,
          b.remarks || null,
          b.dont_disturb ? 1 : 0,
          attendeeCount,
        ]
      );

      const bookingId = r.insertId;

      // Insert one row per selected desk. The unique key
      // (booking_id, desk_id) silently drops accidental duplicates.
      for (const deskId of deskIdList) {
        await conn.execute(
          'INSERT IGNORE INTO `booking_desks` (booking_id, desk_id) VALUES (?, ?)',
          [bookingId, deskId]
        );
      }
      for (const g of guests) {
        await conn.execute(
          'INSERT INTO `booking_guests` (booking_id, fname, lname, contact_no, email) VALUES (?, ?, ?, ?, ?)',
          [bookingId, g.fname || null, g.lname || null, g.contact_no || g.contactNo || null, g.email || null]
        );
      }
      // F06 - validate pantry orders point to items in pantries linked to
      // this facility. Skip silently if not (defensive; UI should never send
      // these but a malicious client might).
      if (pantryOrders.length > 0) {
        const itemIds = pantryOrders.map((o) => o.menu_item_id);
        const placeholders = itemIds.map(() => '?').join(',');
        const [validRows] = await conn.execute(
          'SELECT mi.id FROM `pantry_menu_items` mi ' +
          ' INNER JOIN `facility_pantries` fp ON fp.pantry_id = mi.pantry_id ' +
          ' WHERE fp.facility_id = ? AND mi.id IN (' + placeholders + ')',
          [facilityId, ...itemIds]
        );
        const validSet = new Set(validRows.map((r) => r.id));
        for (const order of pantryOrders) {
          if (!validSet.has(order.menu_item_id)) continue;
          await conn.execute(
            'INSERT INTO `booking_pantry_orders` (booking_id, menu_item_id, quantity) VALUES (?, ?, ?)',
            [bookingId, order.menu_item_id, order.quantity]
          );
        }
      }

      for (const mid of mealTimeIds) {
        await conn.execute(
          'INSERT IGNORE INTO `booking_meals` (booking_id, meal_time_id) VALUES (?, ?)',
          [bookingId, mid]
        );
      }

      // Race-safe re-check INSIDE the same txn, with FOR SHARE gap locks.
      // The fresh row is included in this SUM (our own insert is visible
      // to us). Any concurrent insert into the same window either:
      //   - committed before us: its row shows up in the SUM and we roll back
      //   - is waiting: our FOR SHARE blocks it; we commit, it proceeds and
      //     hits the same wall
      const totalInWindow = await sumOverlapAttendees(
        (sql, params) => conn.execute(sql, params),
        facilityId, startAt, endAt,
        { forShare: true }
      );

      // Re-resolve effective capacity inside the txn so any slot override
      // (F01) takes priority over the bare facility.capacity. This guards
      // shared facilities where the operator caps a peak slot below the
      // room's nominal size (e.g. 5-seat cap during a 1-2pm lunch window
      // even though the room seats 20).
      // The bare facility cap is the BOOKABLE one (capacity - offline);
      // offline seats are held back from every shared check.
      const effRace = await slotOverrides.effectiveCapacity(facilityId, startAt, endAt);
      console.log(effRace)
      const bookableCap = Math.max(0,
        (Number(facility.capacity) || 0) - (Number(facility.offline_capacity) || 0)
      );
      const raceCapacity = Math.max(0, Number(
        effRace.matched ? effRace.max : bookableCap
      ) || 0);

      if (facility.shared_booking) {
        if (totalInWindow > raceCapacity) {
          // Custom marker so the outer catch can produce a clean 409.
          const e = new Error('CAPACITY_EXCEEDED');
          e._capacity = raceCapacity;
          e._totalInWindow = totalInWindow;
          throw e;
        }
      } else {
        // Exclusive: anyone else having ANY seat in this window means we
        // collided with a concurrent insert.
        if (totalInWindow > attendeeCount) {
          throw new Error('SLOT_TAKEN');
        }
      }

      // F09 - if the booker claimed one or more chairs check none of them
      // are also held by another active booking in this window. desk_id is
      // stored as a comma-joined list when the booker claims multiple
      // chairs at once; we split, then scan overlapping rows with FOR SHARE
      // and reject if any other booking carries any of the same chair ids.
      if (b.desk_id) {
        const claimed = String(b.desk_id).split(',').map((s) => s.trim()).filter(Boolean);
        if (claimed.length > 0) {
          // F09 - VIP defence. Re-load the facility's layout_json and
          // reject if any claimed chair is marked isVip:true. The booker
          // UI hides VIP chairs but a malicious client could POST one by
          // id, so this is the authoritative check.
          const [layoutRows] = await conn.execute(
            'SELECT layout_json FROM `facilities` WHERE id = ? LIMIT 1',
            [facilityId]
          );
          if (layoutRows[0] && layoutRows[0].layout_json) {
            try {
              const layoutRaw = layoutRows[0].layout_json;
              const layout = typeof layoutRaw === 'string' ? JSON.parse(layoutRaw) : layoutRaw;
              const objs = (layout && Array.isArray(layout.objects)) ? layout.objects : [];
              const chairObjs = objs.filter((o) => o && o.type === 'chair');
              const vipSet = new Set(
                chairObjs.filter((o) => o.isVip).map((o) => String(o.id))
              );
              const vipClash = claimed.find((id) => vipSet.has(id));
              if (vipClash) {
                const e = new Error('DESK_VIP');
                e._deskId = vipClash;
                throw e;
              }
              // T1.3 — DESK_UNKNOWN. Every claimed desk_id MUST exist in
              // the facility's current layout. Prevents silent garbage
              // when a client (browser, integration, or mistyped payload)
              // sends an id for a chair that was never in the layout or
              // has since been deleted. Applies to CREATE only; existing
              // bookings that reference orphan ids stay reschedulable via
              // /reschedule (which keeps their desk_id) so we don't
              // suddenly break historical bookings.
              const knownSet = new Set(chairObjs.map((o) => String(o.id)));
              const unknownDesk = claimed.find((id) => !knownSet.has(id));
              if (unknownDesk) {
                const e = new Error('DESK_UNKNOWN');
                e._deskId = unknownDesk;
                throw e;
              }
            } catch (parseErr) {
              if (parseErr && parseErr.message === 'DESK_VIP') throw parseErr;
              if (parseErr && parseErr.message === 'DESK_UNKNOWN') throw parseErr;
              // Malformed layout JSON - log and fall through; we'd
              // rather book than block on a parse failure.
              console.error('[bookings.create] layout_json parse failed for vip check:', parseErr && parseErr.message);
            }
          }

          // Read other-booking desk claims from the junction table. FOR SHARE
          // locks the matching booking rows so a concurrent insert can't
          // race us past this check.
          const [otherRows] = await conn.execute(
            'SELECT DISTINCT bd.desk_id ' +
            '  FROM `booking_desks` bd ' +
            '  INNER JOIN `bookings` b ON b.id = bd.booking_id ' +
            ' WHERE b.facility_id = ? AND b.id <> ? ' +
            '   AND b.trash = 0 ' +
            "   AND b.status IN ('pending', 'approved', 'completed') " +
            '   AND b.start_at < ? AND b.end_at > ? FOR SHARE',
            [facilityId, bookingId, endAt, startAt]
          );
          const takenSet = new Set();
          for (const row of otherRows) {
            if (row.desk_id) takenSet.add(String(row.desk_id).trim());
          }
          const clash = claimed.find((id) => takenSet.has(id));
          if (clash) {
            const e = new Error('DESK_TAKEN');
            e._deskId = clash;
            throw e;
          }
        }
      }

      // Materialize the per-facility approval chain.
      let stepsCreated = 0;
      let firstApprovalId = null;
      let firstApproverId = null;
      if (facility.requires_approval) {
        const m = await materializeChain({ conn, bookingId, facility, booker, stage: 'checkin' });
        stepsCreated = m.stepsCreated;
        firstApprovalId = m.firstApprovalId;
        firstApproverId = m.firstApproverId;
      }

      let finalStatus = 'pending';
      if (!facility.requires_approval || stepsCreated === 0) finalStatus = 'approved';
      if (finalStatus !== 'pending') {
        await conn.execute('UPDATE `bookings` SET status = ? WHERE id = ?', [finalStatus, bookingId]);
      }
      return { bookingId, status: finalStatus, firstApprovalId, firstApproverId };
    });
  } catch (e) {
    if (e && e.message === 'CAPACITY_EXCEEDED') {
      return fail(
        res,
        `Slot just filled up - another booking landed before yours. ` +
        `Only ${e._capacity - (e._totalInWindow - attendeeCount)} seat(s) free now. Pick another time.`,
        409
      );
    }
    if (e && e.message === 'SLOT_TAKEN') {
      return fail(res, 'That slot was just booked by someone else. Pick another time.', 409);
    }
    if (e && e.message === 'DESK_TAKEN') {
      return fail(
        res,
        `Desk ${e._deskId} was just claimed by someone else for this time slot. Pick another chair.`,
        409
      );
    }
    if (e && e.message === 'DESK_VIP') {
      // Defensive 403 - the booker UI never offers VIP chairs, so this
      // can only happen via a tampered request.
      return fail(
        res,
        `Chair ${e._deskId} is reserved and can't be booked.`,
        403
      );
    }
    if (e && e.message === 'DESK_UNKNOWN') {
      // T1.3 - client sent an id for a chair that isn't in the facility's
      // layout (never was, or was deleted after the client cached it).
      // 400 because it's a client-payload problem, not a race.
      return fail(
        res,
        `Chair ${e._deskId} does not exist in this facility. Please refresh and pick a chair from the current layout.`,
        400
      );
    }
    throw e;
  }

  if (txResult.firstApprovalId && txResult.firstApproverId) {
    console.log(
      `[bookings.create] booking #${txResult.bookingId} - kicking approval email to user #${txResult.firstApproverId} (step 1)` +
      ` + submitted email to booker #${booker.id}`
    );
    (async () => {
      // Approver (action needed) + booker (submitted) emails fire in parallel.
      try {
        const token = await issueToken(txResult.firstApprovalId);
        await _sendApprovalEmailWithToken({
          approvalId: txResult.firstApprovalId,
          token,
        });
      } catch (e) {
        console.error('[bookings.create] first-step email failed:', e && e.message);
      }
      try { await _sendBookingSubmittedEmail(txResult.bookingId); }
      catch (e) { console.error('[bookings.create] submitted email failed:', e && e.message); }
    })();
  } else if (facility.requires_approval) {
    console.log(
      `[bookings.create] booking #${txResult.bookingId} - no approver could be resolved (auto-approved)`
    );
    // F07 - auto-approved path: still email the booker with reschedule/cancel links.
    // F09 - and FYI emails to every facility notification recipient.
    (async () => {
      try { await _sendBookingConfirmedEmail(txResult.bookingId); }
      catch (e) { console.error('[bookings.create] confirm email failed:', e && e.message); }
      _sendFacilityNotifications(txResult.bookingId, 'approved');
    })();
  } else {
    console.log(
      `[bookings.create] booking #${txResult.bookingId} - facility does not require approval (auto-approved, sending confirm email)`
    );
    (async () => {
      try { await _sendBookingConfirmedEmail(txResult.bookingId); }
      catch (e) { console.error('[bookings.create] confirm email failed:', e && e.message); }
      _sendFacilityNotifications(txResult.bookingId, 'approved');
    })();
  }

  return created(
    res,
    { id: txResult.bookingId, status: txResult.status },
    txResult.status === 'approved' ? 'Booking confirmed' : 'Booking submitted for approval'
  );
});

// Shared helper - used by bookings.create + approvals.decide. Loads all the
// joined data the email template needs, then fires the templated email.
async function _sendApprovalEmailWithToken({ approvalId, token }) {
  const rows = await query(
    'SELECT ba.id, ba.booking_id, ba.step_order, ba.approver_user_id, ' +
    '       b.title, b.start_at, b.end_at, b.remarks, ' +
    '       f.name AS facility_name, f.type AS facility_type, ' +
    '       u.email AS approver_email, u.name AS approver_name, u.lname AS approver_lname, ' +
    '       bk.name AS booker_name, bk.lname AS booker_lname ' +
    '  FROM `booking_approvals` ba ' +
    '  INNER JOIN `bookings`   b  ON b.id  = ba.booking_id ' +
    '  INNER JOIN `facilities` f  ON f.id  = b.facility_id ' +
    '  INNER JOIN `users`      u  ON u.id  = ba.approver_user_id ' +
    '  INNER JOIN `users`      bk ON bk.id = b.user_id ' +
    ' WHERE ba.id = ? LIMIT 1',
    [approvalId]
  );
  if (rows.length === 0 || !rows[0].approver_email) return;
  const row = rows[0];

  const [totalRow, priorRows] = await Promise.all([
    query('SELECT COUNT(*) cnt FROM `booking_approvals` WHERE booking_id = ?', [row.booking_id]),
    query(
      'SELECT ba.step_order, ba.decision, ba.remark, ' +
      '       u.name AS approver_name, u.lname AS approver_lname ' +
      '  FROM `booking_approvals` ba ' +
      '  LEFT JOIN `users` u ON u.id = ba.approver_user_id ' +
      ' WHERE ba.booking_id = ? AND ba.step_order < ? ' +
      ' ORDER BY ba.step_order',
      [row.booking_id, row.step_order]
    ),
  ]);

  mailer.approvalRequested({
    to: row.approver_email,
    approverName: [row.approver_name, row.approver_lname].filter(Boolean).join(' ') || null,
    bookerName:  [row.booker_name,   row.booker_lname  ].filter(Boolean).join(' ') || null,
    facilityName: row.facility_name,
    facilityType: row.facility_type,
    startAt: typeof row.start_at === 'string' ? row.start_at : new Date(row.start_at).toISOString().replace('T',' ').slice(0,19),
    endAt:   typeof row.end_at   === 'string' ? row.end_at   : new Date(row.end_at  ).toISOString().replace('T',' ').slice(0,19),
    title: row.title,
    remarks: row.remarks,
    stepOrder: row.step_order,
    totalSteps: totalRow[0].cnt,
    priorDecisions: priorRows.map((d) => ({
      step_order: d.step_order,
      decision: d.decision,
      remark: d.remark,
      approver_name: [d.approver_name, d.approver_lname].filter(Boolean).join(' ') || null,
    })),
    token,
  });
}

exports._sendApprovalEmailWithToken = _sendApprovalEmailWithToken;

// ---------- list ------------------------------------------------------

exports.list = asyncHandler(async function (req, res) {
  const limit  = Math.max(1, Math.min(100, parseInt(req.query.limit || '20', 10)));
  const page   = Math.max(1, parseInt(req.query.page  || '1', 10));
  const offset = (page - 1) * limit;

  const where = ['b.trash = 0'];
  const params = [];

  if (req.user.role === 'super_admin') {
    const tid = intOrNull(req.query.tenant_id);
    if (tid !== null) { where.push('b.tenant_id = ?'); params.push(tid); }
  } else {
    where.push('b.tenant_id = ?');
    params.push(req.user.tenant_id);
  }

  const isNonAdmin = req.user.role === 'employee' || req.user.role === 'approver';
  const scope = req.query.scope || (isNonAdmin ? 'mine' : 'tenant');
  if (scope === 'mine') { where.push('b.user_id = ?'); params.push(req.user.id); }
  if (scope === 'team') {
    where.push(
      'b.department_id IN (SELECT id FROM `departments` ' +
      ' WHERE manager_user_id = ? AND trash = 0)'
    );
    params.push(req.user.id);
  }

  if (req.query.status)      { where.push('b.status = ?');      params.push(req.query.status); }
  if (req.query.facility_id) { where.push('b.facility_id = ?'); params.push(intOrNull(req.query.facility_id)); }
  if (req.query.from_date)   { where.push('b.start_at >= ?');   params.push(req.query.from_date); }
  if (req.query.to_date)     { where.push('b.start_at < ?');    params.push(req.query.to_date); }

  // Free-text search across the columns an admin would type from memory:
  // booking title, remarks, the facility's name, and the booker's name /
  // username. LIKE wildcards in the user's query string are escaped so
  // typing "50%" doesn't blow up the WHERE clause.
  const qRaw = String(req.query.q || '').trim();
  if (qRaw) {
    const like = '%' + qRaw.replace(/[%_]/g, '\\$&') + '%';
    where.push(
      '(b.title LIKE ? OR b.remarks LIKE ? OR f.name LIKE ? ' +
      ' OR u.name LIKE ? OR u.lname LIKE ? OR u.username LIKE ?)'
    );
    params.push(like, like, like, like, like, like);
  }

  const whereSql = where.join(' AND ');

  const total = (await query(
    'SELECT COUNT(*) cnt FROM `bookings` b ' +
    '  LEFT JOIN `facilities` f ON f.id = b.facility_id ' +
    '  LEFT JOIN `users`      u ON u.id = b.user_id ' +
    ' WHERE ' + whereSql,
    params
  ))[0].cnt;

  const rows = await query(
    'SELECT b.id, b.tenant_id, b.facility_id, b.user_id, b.department_id, b.title, ' +
    '       b.start_at, b.end_at, b.repeat_type, b.status, b.remarks, b.dont_disturb, ' +
    '       b.attendee_count, b.created_at, ' +
    '       f.name AS facility_name, f.type AS facility_type, ' +
    '       u.name AS booker_name, u.lname AS booker_lname, u.username AS booker_username, ' +
    '       d.name AS department_name ' +
    '  FROM `bookings` b ' +
    '  LEFT JOIN `facilities`  f ON f.id = b.facility_id ' +
    '  LEFT JOIN `users`       u ON u.id = b.user_id ' +
    '  LEFT JOIN `departments` d ON d.id = b.department_id ' +
    ' WHERE ' + whereSql +
    ` ORDER BY b.start_at DESC LIMIT ${limit} OFFSET ${offset}`,
    params
  );

  // "Pending with" - first pending approval ordered by step_order.
  const pendingIds = rows.filter((r) => r.status === 'pending').map((r) => r.id);
  if (pendingIds.length > 0) {
    const placeholders = pendingIds.map(() => '?').join(',');
    const pwRows = await query(
      'SELECT t.booking_id, t.approver_user_id, ' +
      '       u.name AS approver_name, u.lname AS approver_lname, u.email AS approver_email ' +
      '  FROM ( ' +
      '    SELECT ba.booking_id, ba.approver_user_id, ' +
      '           ROW_NUMBER() OVER (PARTITION BY ba.booking_id ORDER BY ba.step_order, ba.id) AS rn ' +
      '      FROM `booking_approvals` ba ' +
      "     WHERE ba.booking_id IN (" + placeholders + ") AND ba.decision = 'pending' " +
      '  ) t ' +
      '  LEFT JOIN `users` u ON u.id = t.approver_user_id ' +
      ' WHERE t.rn = 1',
      pendingIds
    );
    const byBooking = new Map();
    for (const r of pwRows) byBooking.set(r.booking_id, r);
    for (const r of rows) {
      const pw = byBooking.get(r.id);
      if (pw) {
        r.pending_with_user_id = pw.approver_user_id;
        r.pending_with_name = [pw.approver_name, pw.approver_lname].filter(Boolean).join(' ') || null;
        r.pending_with_email = pw.approver_email || null;
      } else {
        r.pending_with_user_id = null;
        r.pending_with_name = null;
        r.pending_with_email = null;
      }
    }
  }

  return ok(res, { data: rows, total, current_page: page, per_page: limit });
});

// ---------- getOne ----------------------------------------------------

exports.getOne = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid id', 400);

  const scope = tenantScopeWhere(req, 'b');
  const rows = await query(
    'SELECT b.*, f.name AS facility_name, f.type AS facility_type, ' +
    '       u.name AS booker_name, u.lname AS booker_lname, ' +
    '       d.name AS department_name ' +
    '  FROM `bookings` b ' +
    '  LEFT JOIN `facilities`  f ON f.id = b.facility_id ' +
    '  LEFT JOIN `users`       u ON u.id = b.user_id ' +
    '  LEFT JOIN `departments` d ON d.id = b.department_id ' +
    ' WHERE b.id = ? AND b.trash = 0' + scope.sql +
    ' LIMIT 1',
    [id, ...scope.params]
  );
  if (rows.length === 0) return notFound(res, 'Booking not found');
  const booking = rows[0];

  const isNonAdmin = req.user.role === 'employee' || req.user.role === 'approver';
  if (isNonAdmin && booking.user_id !== req.user.id) {
    return fail(res, 'Forbidden', 403);
  }

  // F09 — pull claimed desks from the junction table so the response
  // includes a clean array AND a legacy comma-joined `desk_id` for any
  // frontend code still reading the old column shape.
  const deskRows = await query(
    'SELECT desk_id FROM `booking_desks` WHERE booking_id = ? ORDER BY id',
    [id]
  );
  booking.desks = deskRows.map((d) => d.desk_id);
  if (booking.desks.length > 0) {
    booking.desk_id = booking.desks.join(',');
  }

  const [guests, meals, approvals] = await Promise.all([
    query('SELECT id, fname, lname, contact_no, email FROM `booking_guests` WHERE booking_id = ?', [id]),
    query(
      'SELECT m.id, m.name, m.start_time, m.end_time ' +
      '  FROM `booking_meals` bm ' +
      '  INNER JOIN `meal_times` m ON m.id = bm.meal_time_id ' +
      ' WHERE bm.booking_id = ? ORDER BY m.start_time',
      [id]
    ),
    query(
      'SELECT ba.id, ba.step_id, ba.step_order, ba.approver_user_id, ba.decision, ' +
      '       ba.remark, ba.decided_at, ' +
      '       u.name AS approver_name, u.lname AS approver_lname, u.username AS approver_username, ' +
      '       u.email AS approver_email, u.designation AS approver_designation ' +
      '  FROM `booking_approvals` ba ' +
      '  LEFT JOIN `users` u ON u.id = ba.approver_user_id ' +
      ' WHERE ba.booking_id = ? ' +
      ' ORDER BY ba.step_order, ba.id',
      [id]
    ),
  ]);

  return ok(res, { ...booking, guests, meals, approvals });
});

// ---------- cancel ----------------------------------------------------

exports.cancel = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid id', 400);

  const rows = await query(
    'SELECT id, tenant_id, user_id, status, start_at FROM `bookings` WHERE id = ? AND trash = 0 LIMIT 1',
    [id]
  );
  if (rows.length === 0) return notFound(res, 'Booking not found');
  const booking = rows[0];

  if (req.user.role !== 'super_admin' && booking.tenant_id !== req.user.tenant_id) {
    return fail(res, 'Forbidden', 403);
  }
  const isNonAdmin = req.user.role === 'employee' || req.user.role === 'approver';
  if (isNonAdmin && booking.user_id !== req.user.id) {
    return fail(res, 'You can only cancel your own bookings', 403);
  }
  if (booking.status === 'cancelled' || booking.status === 'completed') {
    return fail(res, `Booking is already ${booking.status}`, 422);
  }
  // BUG-06 fix: refuse to cancel a booking whose start time is already past.
  // Cancelling a past booking corrupts history + utilisation analytics; the
  // event already happened (or was missed). Compared in SQL (NOW()) so the
  // check is immune to the Node process timezone.
  const pastCheck = await query('SELECT (? < NOW()) AS in_past', [booking.start_at]);
  if (Number(pastCheck[0].in_past) === 1) {
    return fail(res, 'Past bookings cannot be cancelled.', 422);
  }

  await withTransaction(async function (conn) {
    await conn.execute("UPDATE `bookings` SET status = 'cancelled' WHERE id = ?", [id]);
    await conn.execute(
      "UPDATE `booking_approvals` SET decision = 'rejected', remark = 'Booking cancelled by booker', decided_at = NOW() " +
      " WHERE booking_id = ? AND decision = 'pending'",
      [id]
    );
  });

  // F09 - notify the facility's notification chain that the booking was cancelled.
  _sendFacilityNotifications(id, 'cancelled');

  return ok(res, null, 'Booking cancelled');
});

// ---------- F07: Reschedule / cancel via mail ----------------------------
//
// Helper: send the booking-confirmed email once a booking is approved.
// Issues two single-use tokens (one for reschedule, one for cancel) and
// embeds the deep-links. Called from both bookings.create (auto-approve
// path) and approvals.decide (final-step approve path).

async function _sendBookingConfirmedEmail(bookingId) {
  const rows = await query(
    'SELECT b.id, b.user_id, b.start_at, b.end_at, b.attendee_count, b.checkin_code, ' +
    '       f.name AS facility_name, f.type AS facility_type, ' +
    '       u.email AS booker_email, u.name AS booker_name, u.lname AS booker_lname ' +
    '  FROM `bookings`   b ' +
    '  INNER JOIN `facilities` f ON f.id = b.facility_id ' +
    '  INNER JOIN `users`      u ON u.id = b.user_id ' +
    ' WHERE b.id = ? LIMIT 1',
    [bookingId]
  );
  if (rows.length === 0 || !rows[0].booker_email) return;
  const b = rows[0];

  const [rToken, cToken] = await Promise.all([
    bookingActionTokens.issueToken(bookingId, b.user_id, 'reschedule'),
    bookingActionTokens.issueToken(bookingId, b.user_id, 'cancel'),
  ]);

  const bookerFullName = [b.booker_name, b.booker_lname].filter(Boolean).join(' ') || null;
  const startStr = typeof b.start_at === 'string' ? b.start_at : new Date(b.start_at).toISOString().replace('T', ' ').slice(0, 19);
  const endStr   = typeof b.end_at   === 'string' ? b.end_at   : new Date(b.end_at  ).toISOString().replace('T', ' ').slice(0, 19);

  mailer.bookingConfirmed({
    to: b.booker_email,
    bookerName: bookerFullName,
    bookingId: b.id,
    facilityName: b.facility_name,
    facilityType: b.facility_type,
    startAt: startStr,
    endAt:   endStr,
    attendeeCount: b.attendee_count,
    checkinCode: b.checkin_code,   // M15 - printed on the confirmation for QR check-in
    rescheduleToken: rToken,
    cancelToken: cToken,
  });

  // Fan out to every guest with an email - they get the same approval
  // notice (no reschedule/cancel tokens, only the booker can do that).
  try {
    const guestRows = await query(
      'SELECT fname, lname, email FROM `booking_guests` WHERE booking_id = ? AND email IS NOT NULL AND email <> ""',
      [bookingId]
    );
    for (const g of guestRows) {
      mailer.bookingNotification({
        to: g.email,
        recipientName: [g.fname, g.lname].filter(Boolean).join(' ') || null,
        event: 'approved',
        bookerName: bookerFullName,
        facilityName: b.facility_name,
        facilityType: b.facility_type,
        startAt: startStr, endAt: endStr,
        attendeeCount: b.attendee_count,
        title: null,
      });
    }
  } catch (e) {
    console.error('[bookings.confirm] guest fan-out failed:', e && e.message);
  }
}

exports._sendBookingConfirmedEmail = _sendBookingConfirmedEmail;

// Sent to the booker as soon as their booking is queued for approval.
// Surfaces who the first approver is so they can chase if needed. NOT
// sent on auto-approve (the bookingConfirmed email already covers that
// path).
async function _sendBookingSubmittedEmail(bookingId) {
  const rows = await query(
    'SELECT b.id, b.user_id, b.title, b.start_at, b.end_at, b.attendee_count, ' +
    '       f.name AS facility_name, f.type AS facility_type, ' +
    '       u.email AS booker_email, u.name AS booker_name, u.lname AS booker_lname ' +
    '  FROM `bookings`   b ' +
    '  INNER JOIN `facilities` f ON f.id = b.facility_id ' +
    '  INNER JOIN `users`      u ON u.id = b.user_id ' +
    ' WHERE b.id = ? LIMIT 1',
    [bookingId]
  );
  if (rows.length === 0 || !rows[0].booker_email) return;
  const b = rows[0];

  // Look up step 1's approver (if any) for the "your booking is with X" line.
  const chainRows = await query(
    'SELECT COUNT(*) AS total ' +
    '  FROM `booking_approvals` ' +
    " WHERE booking_id = ? AND stage = 'checkin'",
    [bookingId]
  );
  const totalSteps = Number(chainRows[0]?.total || 0);
  let firstApproverName = null;
  if (totalSteps > 0) {
    const firstRows = await query(
      'SELECT u.name, u.lname ' +
      '  FROM `booking_approvals` ba ' +
      '  LEFT JOIN `users` u ON u.id = ba.approver_user_id ' +
      " WHERE ba.booking_id = ? AND ba.stage = 'checkin' " +
      ' ORDER BY ba.step_order ASC, ba.id ASC LIMIT 1',
      [bookingId]
    );
    if (firstRows[0]) {
      firstApproverName = [firstRows[0].name, firstRows[0].lname].filter(Boolean).join(' ') || null;
    }
  }

  const startStr = typeof b.start_at === 'string' ? b.start_at : new Date(b.start_at).toISOString().replace('T', ' ').slice(0, 19);
  const endStr   = typeof b.end_at   === 'string' ? b.end_at   : new Date(b.end_at  ).toISOString().replace('T', ' ').slice(0, 19);

  mailer.bookingSubmitted({
    to: b.booker_email,
    bookerName: [b.booker_name, b.booker_lname].filter(Boolean).join(' ') || null,
    facilityName: b.facility_name,
    facilityType: b.facility_type,
    startAt: startStr,
    endAt:   endStr,
    attendeeCount: b.attendee_count,
    title: b.title,
    totalSteps,
    firstApproverName,
  });
}
exports._sendBookingSubmittedEmail = _sendBookingSubmittedEmail;

// Sent to the booker every time an approver acts. Covers both intermediate
// step decisions and the final-rejected case. Final-approved is handled
// separately by _sendBookingConfirmedEmail (which carries the reschedule +
// cancel action tokens that the step-decision email doesn't).
//
// Args:
//   approvalId   - the booking_approvals row that was just decided
//   finalStatus  - 'approved' | 'rejected' | null  (null = chain still in progress)
async function _sendBookingStepDecisionEmail({ approvalId, finalStatus }) {
  const rows = await query(
    'SELECT ba.id, ba.booking_id, ba.step_order, ba.decision, ba.remark, ' +
    '       b.user_id, b.title, b.start_at, b.end_at, ' +
    '       f.name AS facility_name, f.type AS facility_type, ' +
    '       bk.email AS booker_email, bk.name AS booker_name, bk.lname AS booker_lname, ' +
    '       du.name AS decider_name, du.lname AS decider_lname ' +
    '  FROM `booking_approvals` ba ' +
    '  INNER JOIN `bookings`   b  ON b.id  = ba.booking_id ' +
    '  INNER JOIN `facilities` f  ON f.id  = b.facility_id ' +
    '  INNER JOIN `users`      bk ON bk.id = b.user_id ' +
    '  LEFT  JOIN `users`      du ON du.id = ba.approver_user_id ' +
    ' WHERE ba.id = ? LIMIT 1',
    [approvalId]
  );
  if (rows.length === 0 || !rows[0].booker_email) return;
  const row = rows[0];

  // Count of steps at the same stage (checkin) for the "step X of Y" copy.
  const totalRow = await query(
    "SELECT COUNT(*) AS cnt FROM `booking_approvals` WHERE booking_id = ? AND stage = 'checkin'",
    [row.booking_id]
  );
  const totalSteps = Number(totalRow[0]?.cnt || 0);

  // Next-up approver (only matters when finalStatus is null AKA still pending).
  let nextApproverName = null;
  if (!finalStatus) {
    const nextRows = await query(
      'SELECT u.name, u.lname ' +
      '  FROM `booking_approvals` ba ' +
      '  LEFT JOIN `users` u ON u.id = ba.approver_user_id ' +
      " WHERE ba.booking_id = ? AND ba.stage = 'checkin' " +
      "   AND ba.decision = 'pending' AND ba.step_order > ? " +
      ' ORDER BY ba.step_order ASC, ba.id ASC LIMIT 1',
      [row.booking_id, row.step_order]
    );
    if (nextRows[0]) {
      nextApproverName = [nextRows[0].name, nextRows[0].lname].filter(Boolean).join(' ') || null;
    }
  }

  const startStr = typeof row.start_at === 'string' ? row.start_at : new Date(row.start_at).toISOString().replace('T', ' ').slice(0, 19);
  const endStr   = typeof row.end_at   === 'string' ? row.end_at   : new Date(row.end_at  ).toISOString().replace('T', ' ').slice(0, 19);

  mailer.bookingStepDecision({
    to: row.booker_email,
    bookerName: [row.booker_name, row.booker_lname].filter(Boolean).join(' ') || null,
    facilityName: row.facility_name,
    facilityType: row.facility_type,
    startAt: startStr,
    endAt:   endStr,
    stepOrder: row.step_order,
    totalSteps,
    decision: row.decision,
    decidedBy: [row.decider_name, row.decider_lname].filter(Boolean).join(' ') || null,
    remark: row.remark,
    finalStatus,
    nextApproverName,
  });
}
exports._sendBookingStepDecisionEmail = _sendBookingStepDecisionEmail;

// F09 notification stage - fire-and-forget emails to every recipient
// configured under stage='notification' for this facility. Called from
// bookings.create (after approve / auto-approve) and bookings.cancel.
async function _sendFacilityNotifications(bookingId, event) {
  try {
    const rows = await query(
      'SELECT b.id, b.user_id, b.tenant_id, b.facility_id, b.department_id, ' +
      '       b.title, b.start_at, b.end_at, b.attendee_count, ' +
      '       f.id AS f_id, f.tenant_id AS f_tenant_id, f.name AS facility_name, f.type AS facility_type, ' +
      '       u.email AS booker_email, u.name AS booker_name, u.lname AS booker_lname, u.department_id AS booker_dept ' +
      '  FROM `bookings` b ' +
      '  INNER JOIN `facilities` f ON f.id = b.facility_id ' +
      '  INNER JOIN `users`      u ON u.id = b.user_id ' +
      ' WHERE b.id = ? LIMIT 1',
      [bookingId]
    );
    if (rows.length === 0) return;
    const b = rows[0];
    const facility = { id: b.f_id, tenant_id: b.f_tenant_id };
    const booker   = { id: b.user_id, tenant_id: b.f_tenant_id, department_id: b.booker_dept };

    // resolveRecipients uses an in-pool connection-style runner. The helper
    // expects an object with .execute returning [rows]; mysql2's pool has
    // execute() but the wrapper would need a real connection. Use the
    // global pool's execute by lifting a small adapter.
    const pool = require('../../db/pool').pool;
    const conn = await pool.getConnection();
    let recipients = [];
    try {
      recipients = await resolveRecipients({ conn, facility, booker, stage: 'notification' });
    } finally { conn.release(); }
    if (recipients.length === 0) return;

    const bookerName = [b.booker_name, b.booker_lname].filter(Boolean).join(' ') || null;
    const startAt = typeof b.start_at === 'string' ? b.start_at : new Date(b.start_at).toISOString().replace('T',' ').slice(0,19);
    const endAt   = typeof b.end_at   === 'string' ? b.end_at   : new Date(b.end_at  ).toISOString().replace('T',' ').slice(0,19);

    for (const r of recipients) {
      mailer.bookingNotification({
        to: r.email,
        recipientName: [r.name, r.lname].filter(Boolean).join(' ') || null,
        event,                 // 'approved' | 'cancelled'
        bookerName,
        facilityName: b.facility_name,
        facilityType: b.facility_type,
        startAt, endAt,
        attendeeCount: b.attendee_count,
        title: b.title,
      });
    }
  } catch (e) {
    console.error('[bookings.notify] failed:', e && e.message);
  }
}
exports._sendFacilityNotifications = _sendFacilityNotifications;

// GET /api/bookings/:id/act
// Consumes one of the booking_action_tokens. Login REQUIRED (the router
// already gates on authRequired); we verify req.user.id === token.user_id.
// Behaviour:
//   action=cancel      -> cancels the booking (same rules as exports.cancel)
//                         and returns { ok:true, action:'cancel' }.
//   action=reschedule  -> validates token and returns { ok:true, action:'reschedule' }.
//                         The frontend then renders the reschedule form
//                         and POSTs to /bookings/:id/reschedule.
exports.actByToken = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid id', 400);
  const rawToken = String(req.query.token || '').trim();
  const action = String(req.query.action || '').toLowerCase();
  if (!rawToken)                                          return fail(res, 'Missing token', 400);
  if (!['cancel', 'reschedule'].includes(action))         return fail(res, 'Invalid action', 400);

  const tokenRow = await bookingActionTokens.consumeToken(rawToken);
  if (!tokenRow || tokenRow.booking_id !== id || tokenRow.action !== action) {
    return fail(res, 'This link is invalid or has expired', 410);
  }
  if (tokenRow.user_id !== req.user.id && req.user.role !== 'super_admin') {
    return fail(res, 'This link belongs to a different account. Please sign in as the booker.', 403);
  }

  // Load booking and apply the same guards used elsewhere.
  const brows = await query(
    'SELECT id, tenant_id, user_id, status, start_at FROM `bookings` WHERE id = ? AND trash = 0 LIMIT 1',
    [id]
  );
  if (brows.length === 0) return notFound(res, 'Booking not found');
  const booking = brows[0];
  if (req.user.role !== 'super_admin' && booking.tenant_id !== req.user.tenant_id) {
    return fail(res, 'Forbidden', 403);
  }
  if (booking.status === 'cancelled' || booking.status === 'completed') {
    return fail(res, `Booking is already ${booking.status}`, 422);
  }
  if (new Date(booking.start_at) < new Date()) {
    return fail(res, 'This booking has already started or finished.', 422);
  }

  if (action === 'cancel') {
    await withTransaction(async function (conn) {
      await conn.execute("UPDATE `bookings` SET status = 'cancelled' WHERE id = ?", [id]);
      await conn.execute(
        "UPDATE `booking_approvals` SET decision = 'rejected', remark = 'Booking cancelled by booker (email link)', decided_at = NOW() " +
        " WHERE booking_id = ? AND decision = 'pending'",
        [id]
      );
    });
    await bookingActionTokens.markUsed(tokenRow.id);
    // F09 - notify facility recipients of the cancel.
    _sendFacilityNotifications(id, 'cancelled');
    return ok(res, { id, action: 'cancel' }, 'Booking cancelled');
  }

  // action === 'reschedule' - we don't consume the token yet, the actual
  // reschedule happens via POST /bookings/:id/reschedule (which the
  // frontend pre-fills using the booking detail). Mark the link "viewed"
  // by issuing a short-lived session-style flag client-side; we still
  // require the same token on the POST so the link remains single-use.
  return ok(res, { id, action: 'reschedule', booking_id: id }, 'Token valid - render reschedule form');
});

// POST /api/bookings/:id/reschedule
// Body: { token, start_at, end_at }
// The token MUST be a booking_action_tokens row with action='reschedule'
// for this booking_id and this req.user.id (or super_admin override).
// Capacity & overlap checks run inside the same transaction.
exports.reschedule = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid id', 400);
  const body = req.body || {};
  const startAt = String(body.start_at || '').trim();
  const endAt   = String(body.end_at   || '').trim();
  const rawToken = String(body.token || '').trim();
  if (!startAt || !endAt) return fail(res, 'start_at and end_at are required', 422);
  if (!rawToken)          return fail(res, 'Missing token', 400);

  const tokenRow = await bookingActionTokens.consumeToken(rawToken);
  if (!tokenRow || tokenRow.booking_id !== id || tokenRow.action !== 'reschedule') {
    return fail(res, 'This link is invalid or has expired', 410);
  }
  if (tokenRow.user_id !== req.user.id && req.user.role !== 'super_admin') {
    return fail(res, 'This link belongs to a different account. Please sign in as the booker.', 403);
  }

  const brows = await query(
    'SELECT b.id, b.tenant_id, b.facility_id, b.user_id, b.attendee_count, b.status, ' +
    '       f.shared_booking, f.capacity ' +
    '  FROM `bookings` b ' +
    '  INNER JOIN `facilities` f ON f.id = b.facility_id ' +
    ' WHERE b.id = ? AND b.trash = 0 LIMIT 1',
    [id]
  );
  if (brows.length === 0) return notFound(res, 'Booking not found');
  const booking = brows[0];
  if (req.user.role !== 'super_admin' && booking.tenant_id !== req.user.tenant_id) {
    return fail(res, 'Forbidden', 403);
  }
  if (!['pending', 'approved'].includes(booking.status)) {
    return fail(res, `Cannot reschedule a ${booking.status} booking`, 422);
  }
  if (new Date(startAt) >= new Date(endAt)) {
    return fail(res, 'End must be after start', 422);
  }
  if (new Date(startAt) < new Date()) {
    return fail(res, 'New start time must be in the future', 422);
  }

  // Re-check advance-booking rules on the NEW start_at. User confirmed
  // "yes re check via mail". Exclude the booking being moved so the per-user
  // counts don't double-count itself.
  const facilityFull = await loadFacility(booking.facility_id);
  if (facilityFull) {
    const advCheck = await checkAdvanceRules(
      facilityFull, startAt, req.user.id, req.user.role,
      { excludeBookingId: id }
    );
    if (!advCheck.ok) return fail(res, advCheck.msg, advCheck.status);
  }

  try {
    await withTransaction(async function (conn) {
      await conn.execute(
        'UPDATE `bookings` SET start_at = ?, end_at = ? WHERE id = ?',
        [startAt, endAt, id]
      );
      const [overlapRows] = await conn.execute(
        "SELECT COALESCE(SUM(attendee_count), 0) AS total " +
        "  FROM `bookings` " +
        " WHERE facility_id = ? AND id <> ? AND status IN ('pending','approved','completed') " +
        "   AND start_at < ? AND end_at > ? FOR SHARE",
        [booking.facility_id, id, endAt, startAt]
      );
      const total = Number(overlapRows[0].total) + Number(booking.attendee_count);
      const effResched = await slotOverrides.effectiveCapacity(booking.facility_id, startAt, endAt);
      const reschedCap = Math.max(0, Number(
        effResched.matched ? effResched.max : booking.capacity
      ) || 0);
      if (booking.shared_booking === 1) {
        if (total > reschedCap) {
          const err = new Error('CAPACITY_EXCEEDED');
          err._capacity = reschedCap;
          err._totalInWindow = total;
          throw err;
        }
      } else if (Number(overlapRows[0].total) > 0) {
        throw new Error('SLOT_TAKEN');
      }
    });
  } catch (e) {
    if (e && e.message === 'CAPACITY_EXCEEDED') {
      return fail(res, `Only ${e._capacity - (e._totalInWindow - Number(booking.attendee_count))} seat(s) free in that slot.`, 409);
    }
    if (e && e.message === 'SLOT_TAKEN') {
      return fail(res, 'That slot is already taken. Pick another time.', 409);
    }
    throw e;
  }

  await bookingActionTokens.markUsed(tokenRow.id);
  console.log(`[bookings.reschedule] booking #${id} moved to ${startAt} - ${endAt}`);
  return ok(res, { id, start_at: startAt, end_at: endAt }, 'Booking rescheduled');
});
// user.tenant_id) {
//     return fail(res, 'Forbidden', 403);
//   }
//   if (!['pending', 'approved'].includes(booking.status)) {
//     return fail(res, `Cannot reschedule a ${booking.status} booking`, 422);
//   }
//   if (new Date(startAt) >= new Date(endAt)) {
//     return fail(res, 'End must be after start', 422);
//   }
//   if (new Date(startAt) < new Date()) {
//     return fail(res, 'New start time must be in the future', 422);
//   }

//   // Re-check advance-booking rules on the NEW start_at. User confirmed
//   // "yes re check via mail". Exclude the booking being moved so the per-user
//   // counts don't double-count itself.
//   const facilityFull = await loadFacility(booking.facility_id);
//   if (facilityFull) {
//     const advCheck = await checkAdvanceRules(
//       facilityFull, startAt, req.user.id, req.user.role,
//       { excludeBookingId: id }
//     );
//     if (!advCheck.ok) return fail(res, advCheck.msg, advCheck.status);
//   }

//   try {
//     await withTransaction(async function (conn) {
//       await conn.execute(
//         'UPDATE `bookings` SET start_at = ?, end_at = ? WHERE id = ?',
//         [startAt, endAt, id]
//       );
//       const [overlapRows] = await conn.execute(
//         "SELECT COALESCE(SUM(attendee_count), 0) AS total " +
//         "  FROM `bookings` " +
//         " WHERE facility_id = ? AND id <> ? AND status IN ('pending','approved','completed') " +
//         "   AND start_at < ? AND end_at > ? FOR SHARE",
//         [booking.facility_id, id, endAt, startAt]
//       );
//       const total = Number(overlapRows[0].total) + Number(booking.attendee_count);
//       const effResched = await slotOverrides.effectiveCapacity(booking.facility_id, startAt, endAt);
//       const reschedCap = Math.max(0, Number(
//         effResched.matched ? effResched.max : booking.capacity
//       ) || 0);
//       if (booking.shared_booking === 1) {
//         if (total > reschedCap) {
//           const err = new Error('CAPACITY_EXCEEDED');
//           err._capacity = reschedCap;
//           err._totalInWindow = total;
//           throw err;
//         }
//       } else if (Number(overlapRows[0].total) > 0) {
//         throw new Error('SLOT_TAKEN');
//       }
//     });
//   } catch (e) {
//     if (e && e.message === 'CAPACITY_EXCEEDED') {
//       return fail(res, `Only ${e._capacity - (e._totalInWindow - Number(booking.attendee_count))} seat(s) free in that slot.`, 409);
//     }
//     if (e && e.message === 'SLOT_TAKEN') {
//       return fail(res, 'That slot is already taken. Pick another time.', 409);
//     }
//     throw e;
//   }

//   await bookingActionTokens.markUsed(tokenRow.id);
//   console.log(`[bookings.reschedule] booking #${id} moved to ${startAt} - ${endAt}`);
//   return ok(res, { id, start_at: startAt, end_at: endAt }, 'Booking rescheduled');
// });
//     'SELECT b.id, b.tenant_id, b.facility_id, b.user_id, b.attendee_count, b.status, ' +
//     '       f.shared_booking, f.capacity ' +
//     '  FROM `bookings` b ' +
//     '  INNER JOIN `facilities` f ON f.id = b.facility_id ' +
//     ' WHERE b.id = ? AND b.trash = 0 LIMIT 1',
//     [id]
//   );
//   if (brows.length === 0) return notFound(res, 'Booking not found');
//   const booking = brows[0];
//   if (req.user.role !== 'super_admin' && booking.tenant_id !== req.user.tenant_id) {
//     return fail(res, 'Forbidden', 403);
//   }
//   if (!['pending', 'approved'].includes(booking.status)) {
//     return fail(res, `Cannot reschedule a ${booking.status} booking`, 422);
//   }
//   if (new Date(startAt) >= new Date(endAt)) {
//     return fail(res, 'End must be after start', 422);
//   }
//   if (new Date(startAt) < new Date()) {
//     return fail(res, 'New start time must be in the future', 422);
//   }

//   // Re-check advance-booking rules on the NEW start_at (excl. self).
//   const facilityFull = await loadFacility(booking.facility_id);
//   if (facilityFull) {
//     const advCheck = await checkAdvanceRules(
//       facilityFull, startAt, req.user.id, req.user.role,
//       { excludeBookingId: id }
//     );
//     if (!advCheck.ok) return fail(res, advCheck.msg, advCheck.status);
//   }

//   try {
//     await withTransaction(async function (conn) {
//       await conn.execute(
//         'UPDATE `bookings` SET start_at = ?, end_at = ? WHERE id = ?',
//         [startAt, endAt, id]
//       );
//       const [overlapRows] = await conn.execute(
//         "SELECT COALESCE(SUM(attendee_count), 0) AS total " +
//         "  FROM `bookings` " +
//         " WHERE facility_id = ? AND id <> ? AND status IN ('pending','approved','completed') " +
//         "   AND start_at < ? AND end_at > ? FOR SHARE",
//         [booking.facility_id, id, endAt, startAt]
//       );
//       const total = Number(overlapRows[0].total) + Number(booking.attendee_count);
//       const effResched = await slotOverrides.effectiveCapacity(booking.facility_id, startAt, endAt);
//       const reschedCap = Math.max(0, Number(
//         effResched.matched ? effResched.max : booking.capacity
//       ) || 0);
//       if (booking.shared_booking === 1) {
//         if (total > reschedCap) {
//           const err = new Error('CAPACITY_EXCEEDED');
//           err._capacity = reschedCap;
//           err._totalInWindow = total;
//           throw err;
//         }
//       } else if (Number(overlapRows[0].total) > 0) {
//         throw new Error('SLOT_TAKEN');
//       }
//     });
//   } catch (e) {
//     if (e && e.message === 'CAPACITY_EXCEEDED') {
//       return fail(res, `Only ${e._capacity - (e._totalInWindow - Number(booking.attendee_count))} seat(s) free in that slot.`, 409);
//     }
//     if (e && e.message === 'SLOT_TAKEN') {
//       return fail(res, 'That slot is already taken. Pick another time.', 409);
//     }
//     throw e;
//   }

//   await bookingActionTokens.markUsed(tokenRow.id);
//   console.log(`[bookings.reschedule] booking #${id} moved to ${startAt} - ${endAt}`);
//   return ok(res, { id, start_at: startAt, end_at: endAt }, 'Booking rescheduled');

// checkinWindow.js — the ONE place that decides whether "now" is inside a
// booking's check-in window.
//
// Window: [ start_at − opensMin , start_at + graceMin ]
//   opensMin  how early you may check in before your booking starts
//   graceMin  how late you may still check in after start before it's a no-show
//
// Grace is a flat per-tenant constant for now (env-tunable). When the
// per-facility grace-config feature (M3, status-report #4) lands, swap the
// `config.checkin.*` reads here for the facility column — callers don't change.
//
// All comparisons are done against the process clock (new Date()), matching
// how the rest of the bookings controller compares start_at (which comes back
// as a server-timezone string because the pool runs with dateStrings:true).
// The phone never decides the window; the server does.

'use strict';

const config = require('../config');

/**
 * @param {string|Date} startAt  booking start (DB string or Date)
 * @param {Date}        [now]    defaults to new Date()
 * @returns {{ verdict:'ok'|'too_early'|'too_late', opensAt:Date, closesAt:Date, now:Date }}
 */
function evaluate(startAt, now) {
  const start = startAt instanceof Date ? startAt : new Date(startAt);
  const at = now || new Date();
  const opensAt  = new Date(start.getTime() - config.checkin.opensMin * 60 * 1000);
  const closesAt = new Date(start.getTime() + config.checkin.graceMin * 60 * 1000);

  let verdict = 'ok';
  if (at < opensAt) verdict = 'too_early';
  else if (at > closesAt) verdict = 'too_late';

  return { verdict, opensAt, closesAt, now: at };
}

module.exports = { evaluate };

// Facilities CRUD + nested operating_hours + per-facility approval chain.
//
// New since migration 019:
//   - facilities.facility_approver_user_id      ("the facility person")
//   - facility_approval_chains rows             (the chain UI on facility form)
//
// When a facility is created, two default chain rows are inserted:
//   1. dynamic_dept_manager   (resolved at booking time from booker -> dept -> manager)
//   2. user:facility_approver_user_id  (only if that field was provided)

const { query, execute, withTransaction } = require('../../db/pool');
const { ok, created, fail } = require('../../utils/response');
const asyncHandler = require('../../utils/asyncHandler');
const { intOrNull, assertOwnership } = require('../../utils/tenantScope');
const { scopeOrgWhere } = require('../../utils/orgScope');
// M1 (stable desk ids): single owner of chair-id parsing/validation rules.
const deskLayout = require('../../utils/deskLayout');

// Chair ids referenced by this facility's future bookings (pending/approved).
// Used to refuse layout saves that would leave booked desks dangling.
// Reads from the booking_desks junction table (migration 053) so pre-split
// legacy data + new one-row-per-desk inserts are both covered.
async function futureBookedDeskIds(facilityId) {
  const rows = await query(
    "SELECT DISTINCT bd.desk_id FROM `booking_desks` bd " +
    "  INNER JOIN `bookings` b ON b.id = bd.booking_id " +
    " WHERE b.facility_id = ? AND b.trash = 0 " +
    "   AND b.status IN ('pending','approved') AND b.end_at >= NOW()",
    [facilityId]
  );
  const out = new Set();
  for (const r of rows) {
    if (r.desk_id) out.add(String(r.desk_id).trim());
  }
  return [...out];
}

const VALID_TYPES = ['meeting_room','gym','conference_room','desk','swimming_pool','other'];

// Helper: load the chain rows for a facility, joined to the approver user
// (for `user`-kind rows). Used by getOne + facilityChains.list.
// F02 - second arg `stage` defaults to 'checkin' (so getOne's chain remains
// the pre-booking workflow). Pass 'checkout' to load the post-booking chain.
async function loadChain(facilityId, stage) {
  // F09 - 'notification' is a third stage for FYI-only recipients; defaults
  // remain 'checkin' so existing callers stay untouched.
  const stageVal =
    stage === 'checkout'     ? 'checkout'
    : stage === 'notification' ? 'notification'
    : stage === 'cleanup'      ? 'cleanup'
    : 'checkin';
  return query(
    'SELECT c.id, c.facility_id, c.stage, c.step_order, c.approver_kind, c.approver_user_id, ' +
    '       u.name AS approver_name, u.lname AS approver_lname, u.username AS approver_username, ' +
    '       u.email AS approver_email, u.designation AS approver_designation ' +
    '  FROM `facility_approval_chains` c ' +
    '  LEFT JOIN `users` u ON u.id = c.approver_user_id ' +
    ' WHERE c.facility_id = ? AND c.stage = ? ' +
    ' ORDER BY c.step_order',
    [facilityId, stageVal]
  );
}

exports.list = asyncHandler(async function (req, res) {
  const limit  = Math.max(1, Math.min(100, parseInt(req.query.limit || '50', 10)));
  const page   = Math.max(1, parseInt(req.query.page  || '1', 10));
  const offset = (page - 1) * limit;

  const where = ['f.trash = 0'];
  const params = [];

  if (req.user.role === 'super_admin') {
    const tid = intOrNull(req.query.tenant_id);
    if (tid !== null) { where.push('f.tenant_id = ?'); params.push(tid); }
  } else {
    where.push('f.tenant_id = ?');
    params.push(req.user.tenant_id);
  }

  const siteId = intOrNull(req.query.site_id);
  if (siteId !== null) { where.push('f.site_id = ?'); params.push(siteId); }

  // Org scoping — facilities inherit their org via the parent site.
  const orgScope = scopeOrgWhere(req, 's.organisation_id');
  if (orgScope.sql) {
    where.push(orgScope.sql.replace(/^\s*AND\s+/, ''));
    params.push(...orgScope.params);
  }

  if (req.query.type) { where.push('f.type = ?'); params.push(req.query.type); }
  if (req.query.q)    {
    where.push('f.name LIKE ?');
    params.push('%' + req.query.q + '%');
  }
  const whereSql = where.join(' AND ');

  const total = (await query(
    'SELECT COUNT(*) cnt FROM `facilities` f ' +
    ' LEFT JOIN `sites` s ON s.id = f.site_id ' +
    ' WHERE ' + whereSql,
    params
  ))[0].cnt;

  const rows = await query(
    'SELECT f.id, f.tenant_id, f.site_id, s.organisation_id, f.floor_id, f.name, f.type, f.capacity, f.offline_capacity, ' +
    '       f.min_advance_minutes, f.max_advance_days, f.max_per_user_per_day, ' +
    '       f.max_per_user_per_week, f.max_per_user_per_month, ' +
    '       f.pre_end_notify_minutes, f.grace_period_minutes, ' +
    '       f.description, f.terms_and_conditions, f.image_url, f.layout_json, f.requires_approval, f.shared_booking, ' +
    '       f.facility_approver_user_id, f.public_listed, ' +
    '       f.status, f.created_at, ' +
    '       t.name AS tenant_name, s.name AS site_name, fl.name AS floor_name ' +
    '  FROM `facilities` f ' +
    '  LEFT JOIN `tenants` t  ON t.id  = f.tenant_id ' +
    '  LEFT JOIN `sites`   s  ON s.id  = f.site_id ' +
    '  LEFT JOIN `floors`  fl ON fl.id = f.floor_id ' +
    ' WHERE ' + whereSql +
    ` ORDER BY f.id DESC LIMIT ${limit} OFFSET ${offset}`,
    params
  );

  // BUG-27 fix: `layout_json.imageUrl` holds a base64-encoded floor plan
  // image — ~145 KB per facility. The LIST payload is used by cards + the
  // chair picker, which both need the object coordinates but NOT the
  // background image. Stripping imageUrl here keeps the chair picker
  // functional while cutting response size by ~95%. The full image is
  // still available from getOne (facility detail) for the editor.
  for (const r of rows) {
    r.layout_json = stripLayoutImage(r.layout_json);
  }

  return ok(res, { data: rows, total: total, current_page: page, per_page: limit });
});

// Removes the heavy base64 imageUrl from a facility's layout_json while
// preserving everything else (objects/chairs, dimensions, mode). Accepts
// either a JSON string or a parsed object; always returns the same type
// it was given so downstream serialisation is unchanged.
function stripLayoutImage(raw) {
  if (!raw) return raw;
  try {
    const wasString = typeof raw === 'string';
    const obj = wasString ? JSON.parse(raw) : raw;
    if (obj && typeof obj === 'object' && 'imageUrl' in obj) {
      // Only strip inline data URLs — if it's an https:// path, keep it
      // (that's a cheap reference, not a payload bomb).
      const url = obj.imageUrl;
      if (typeof url === 'string' && url.startsWith('data:')) {
        obj.imageUrl = null;
        obj._imageStripped = true;  // hint for the frontend to request detail if needed
      }
    }
    return wasString ? JSON.stringify(obj) : obj;
  } catch {
    // Malformed JSON — return as-is; the frontend already handles that path.
    return raw;
  }
}

exports.getOne = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid id', 400);
  const r = await assertOwnership(req, 'facilities', id);
  if (!r.ok) return fail(res, r.msg, r.status);

  const [hours, chain] = await Promise.all([
    query(
      'SELECT id, day_of_week, open_time, close_time, slot_minutes ' +
      '  FROM `facility_operating_hours` WHERE facility_id = ? ORDER BY day_of_week',
      [id]
    ),
    loadChain(id),
  ]);
  return ok(res, Object.assign({}, r.row, { operating_hours: hours, approval_chain: chain }));
});

exports.create = asyncHandler(async function (req, res) {
  const b = req.body || {};
  if (!b.name)                          return fail(res, 'name is required', 422);
  if (!b.type || !VALID_TYPES.includes(b.type))
                                        return fail(res, 'type is required and must be one of: ' + VALID_TYPES.join(', '), 422);
  if (!b.site_id)                       return fail(res, 'site_id is required', 422);

  // BUG-05 fix: numeric sanity. The frontend caps these, but a direct API
  // caller could still POST negatives or offline > capacity, which would
  // break availability math (seats_remaining going negative, etc.).
  const capCheck = intOrNull(b.capacity);
  if (capCheck !== null && capCheck < 0) {
    return fail(res, 'capacity must be zero or greater', 422);
  }
  const offlineCheck = intOrNull(b.offline_capacity);
  if (offlineCheck !== null && offlineCheck < 0) {
    return fail(res, 'offline_capacity must be zero or greater', 422);
  }
  if (capCheck !== null && offlineCheck !== null && offlineCheck > capCheck) {
    return fail(res, 'offline_capacity cannot exceed capacity', 422);
  }

  const site = await assertOwnership(req, 'sites', intOrNull(b.site_id));
  if (!site.ok) return fail(res, site.msg, site.status);

  // Cross-org guard for org-scoped roles.
  const role = req.user.role;
  if (role !== 'super_admin' && role !== 'tenant_admin') {
    if (site.row.organisation_id !== req.user.organisation_id) {
      return fail(res, 'Forbidden: site belongs to a different organisation', 403);
    }
  }

  let floorId = intOrNull(b.floor_id);
  if (floorId !== null) {
    const floor = await assertOwnership(req, 'floors', floorId);
    if (!floor.ok || floor.row.tenant_id !== site.row.tenant_id) {
      return fail(res, 'floor_id is not valid for this tenant/site', 422);
    }
  }

  // facility_approver_user_id, when given, must belong to the same tenant.
  const facilityApproverId = intOrNull(b.facility_approver_user_id);
  if (facilityApproverId !== null) {
    const rows = await query(
      'SELECT id FROM `users` WHERE id = ? AND tenant_id = ? AND trash = 0 AND status = 1 LIMIT 1',
      [facilityApproverId, site.row.tenant_id]
    );
    if (rows.length === 0) return fail(res, 'facility_approver_user_id is not a valid user in this tenant', 422);
  }

  // Sanitise advance-booking rule inputs. Each is optional; null = no rule.
  // Negative values are coerced to null (treat "-1" the same as blank).
  function ruleVal(v) {
    const n = intOrNull(v);
    if (n === null) return null;
    return n < 0 ? null : n;
  }
  const minAdvMin    = ruleVal(b.min_advance_minutes);
  // Server-side cap: even if a malicious client sends 999, we store 60.
  // Matches the frontend constraint (FacilityFormPage inputProps max=60).
  let maxAdvDays     = ruleVal(b.max_advance_days);
  if (maxAdvDays !== null && maxAdvDays > 60) maxAdvDays = 60;
  if (maxAdvDays !== null && maxAdvDays < 0)  maxAdvDays = 0;
  const maxPerDay    = ruleVal(b.max_per_user_per_day);
  const maxPerWeek   = ruleVal(b.max_per_user_per_week);
  const maxPerMonth  = ruleVal(b.max_per_user_per_month);
  // Pre-end cleanup notification lead time (minutes before end_at).
  // NULL/0 disables the feature for the facility.
  const preEndMin    = ruleVal(b.pre_end_notify_minutes);
  // M3 - no-show grace override (minutes). NULL = inherit org/tenant/env.
  const graceMin     = ruleVal(b.grace_period_minutes);

  // M1: pre-insert layout validation (charset + duplicate ids). Canonical id
  // assignment needs the facility id, so it happens post-insert inside the txn.
  if (b.layout_json) {
    const check = deskLayout.validateAndNormalizeLayout({ layout: b.layout_json, facilityId: 0 });
    if (!check.ok) return fail(res, check.message, 400, { code: check.code, conflicts: check.conflicts });
  }

  const newId = await withTransaction(async function (conn) {
    // Clamp offline_capacity to [0, capacity] so we never end up with a
    // facility whose offline reservation exceeds its total seat count.
    const capVal     = intOrNull(b.capacity) || 0;
    const offlineRaw = intOrNull(b.offline_capacity) || 0;
    const offlineVal = Math.max(0, Math.min(capVal, offlineRaw));

    const [r] = await conn.execute(
      'INSERT INTO `facilities` (tenant_id, site_id, floor_id, name, type, capacity, offline_capacity, ' +
      '       min_advance_minutes, max_advance_days, max_per_user_per_day, ' +
      '       max_per_user_per_week, max_per_user_per_month, pre_end_notify_minutes, grace_period_minutes, ' +
      '       description, terms_and_conditions, image_url, layout_json, requires_approval, shared_booking, facility_approver_user_id) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [
        site.row.tenant_id, site.row.id, floorId,
        b.name, b.type, capVal, offlineVal,
        minAdvMin, maxAdvDays, maxPerDay, maxPerWeek, maxPerMonth, preEndMin, graceMin,
        b.description || null, b.terms_and_conditions || null, b.image_url || null,
        b.layout_json ? (typeof b.layout_json === 'string' ? b.layout_json : JSON.stringify(b.layout_json)) : null,
        b.requires_approval ? 1 : 0,
        b.shared_booking ? 1 : 0,
        facilityApproverId,
      ]
    );
    const facilityId = r.insertId;

    // M1: assign canonical FAC<id>-D<seq> ids to any chairs saved without one,
    // now that the facility id exists. Same transaction — the facility is
    // never visible with unnormalized chair ids.
    if (b.layout_json) {
      const norm = deskLayout.validateAndNormalizeLayout({ layout: b.layout_json, facilityId });
      if (norm.ok && norm.assigned > 0) {
        await conn.execute('UPDATE `facilities` SET layout_json = ? WHERE id = ?', [norm.layoutJson, facilityId]);
      }
    }

    // Default chain: step 1 = dept manager, step 2 = facility approver (if set).
    // The UI on the facility form can replace this entire chain via PUT
    // /api/facilities/:id/chain after create if the admin wants something
    // different.
    await conn.execute(
      "INSERT INTO `facility_approval_chains` (facility_id, step_order, approver_kind, approver_user_id) " +
      "VALUES (?, 1, 'dynamic_dept_manager', NULL)",
      [facilityId]
    );
    if (facilityApproverId !== null) {
      await conn.execute(
        "INSERT INTO `facility_approval_chains` (facility_id, step_order, approver_kind, approver_user_id) " +
        "VALUES (?, 2, 'user', ?)",
        [facilityId, facilityApproverId]
      );
    }
    return facilityId;
  });

  return created(res, { id: newId }, 'Facility created');
});

exports.update = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid id', 400);
  const r = await assertOwnership(req, 'facilities', id);
  if (!r.ok) return fail(res, r.msg, r.status);

  // Cross-org guard: an org_admin can only edit facilities inside their org.
  const role = req.user.role;
  if (role !== 'super_admin' && role !== 'tenant_admin') {
    const siteRow = (await query(
      'SELECT organisation_id FROM `sites` WHERE id = ? LIMIT 1',
      [r.row.site_id]
    ))[0];
    if (!siteRow || siteRow.organisation_id !== req.user.organisation_id) {
      return fail(res, 'Forbidden', 403);
    }
  }

  const b = req.body || {};
  if (b.type && !VALID_TYPES.includes(b.type)) {
    return fail(res, 'type must be one of: ' + VALID_TYPES.join(', '), 422);
  }

  // BUG-05 fix: mirror create-flow numeric sanity on update too. Also
  // cross-check offline against the EFFECTIVE capacity (new value if sent,
  // otherwise the existing row's capacity).
  if (b.capacity !== undefined) {
    const n = intOrNull(b.capacity);
    if (n !== null && n < 0) return fail(res, 'capacity must be zero or greater', 422);
  }
  if (b.offline_capacity !== undefined) {
    const n = intOrNull(b.offline_capacity);
    if (n !== null && n < 0) return fail(res, 'offline_capacity must be zero or greater', 422);
    const effectiveCap = b.capacity !== undefined ? (intOrNull(b.capacity) || 0) : (r.row.capacity || 0);
    if (n !== null && n > effectiveCap) {
      return fail(res, 'offline_capacity cannot exceed capacity', 422);
    }
  }

  // Allow nulling facility_approver_user_id by passing null explicitly.
  // Distinguish "not provided" (undefined) from "set to null".
  const hasApprover = Object.prototype.hasOwnProperty.call(b, 'facility_approver_user_id');
  const newApprover = hasApprover ? intOrNull(b.facility_approver_user_id) : undefined;
  if (hasApprover && newApprover !== null) {
    const rows = await query(
      'SELECT id FROM `users` WHERE id = ? AND tenant_id = ? AND trash = 0 AND status = 1 LIMIT 1',
      [newApprover, r.row.tenant_id]
    );
    if (rows.length === 0) return fail(res, 'facility_approver_user_id is not a valid user in this tenant', 422);
  }

  // shared_booking is a hard 0/1 flag; treat undefined as "leave alone" so
  // partial PATCH-style updates don't clobber it.
  const hasShared = Object.prototype.hasOwnProperty.call(b, 'shared_booking');
  const sharedVal = hasShared ? (b.shared_booking ? 1 : 0) : null;

  // F09 - layout_json. Pass null to "leave alone"; empty string clears it.
  const hasLayout = Object.prototype.hasOwnProperty.call(b, 'layout_json');
  let layoutVal = hasLayout
    ? (b.layout_json == null ? null : (typeof b.layout_json === 'string' ? b.layout_json : JSON.stringify(b.layout_json)))
    : null;

  // T1.1 - Save-time chair-id integrity. Reject the save if the incoming
  // layout has duplicate chair ids OR renames a chair that has active
  // bookings under its old id (which would silently orphan the history).
  //
  // Applies only when `layout_json` is present in the payload. Empty
  // string (clear layout) is allowed — no chairs = no conflicts.
  if (hasLayout && layoutVal) {
    let incomingLayout = null;
    try {
      incomingLayout = typeof layoutVal === 'string' ? JSON.parse(layoutVal) : layoutVal;
    } catch (parseErr) {
      return fail(res, 'layout_json is not valid JSON', 422);
    }
    const objs = (incomingLayout && Array.isArray(incomingLayout.objects)) ? incomingLayout.objects : [];
    const chairIds = objs
      .filter((o) => o && o.type === 'chair' && o.id)
      .map((o) => String(o.id));

    // (a) Duplicate ids inside the SAME layout — always rejected. Two
    // chairs with the same id would collapse into one at booking-check
    // time and silently mis-route bookings.
    const seen = new Set();
    for (const cid of chairIds) {
      if (seen.has(cid)) {
        return fail(res, `Duplicate chair id in layout: ${cid}`, 400, { error_code: 'DESK_ID_CONFLICT', desk_id: cid });
      }
      seen.add(cid);
    }

    // (b) Renamed / removed chair with active bookings. Compare the new
    // id set against the current bookings and flag any orphaned id that
    // is referenced by an active (not cancelled / not trashed) booking.
    // This preserves the historical link — the admin can either keep the
    // old id in the layout OR cancel the affected bookings first.
    // Reads via the booking_desks junction (migration 053).
    const activeBookings = await query(
      "SELECT DISTINCT bd.desk_id FROM `booking_desks` bd " +
      "  INNER JOIN `bookings` b ON b.id = bd.booking_id " +
      " WHERE b.facility_id = ? AND b.trash = 0 " +
      "   AND b.status IN ('pending','approved','completed')",
      [id]
    );
    const claimedInBookings = new Set();
    for (const row of activeBookings) {
      if (row.desk_id) claimedInBookings.add(String(row.desk_id).trim());
    }
    const layoutSet = new Set(chairIds);
    for (const cid of claimedInBookings) {
      if (!layoutSet.has(cid)) {
        return fail(
          res,
          `Chair ${cid} is referenced by ${activeBookings.length} active booking(s) but is missing / renamed in the new layout. ` +
          `Either keep the chair id, or cancel those bookings first.`,
          400,
          { error_code: 'DESK_ID_CONFLICT', desk_id: cid }
        );
      }
    }
  }

  // Advance-booking rules: each is nullable INT. Treat key-not-present as
  // "leave alone"; key-present-with-null-or-empty as "clear" (no limit);
  // a non-negative number as "set"; negative → clear.
  function ruleField(key) {
    if (!Object.prototype.hasOwnProperty.call(b, key)) {
      return { present: false, value: null };
    }
    const raw = b[key];
    if (raw === null || raw === '' || raw === undefined) {
      return { present: true, value: null };
    }
    const n = intOrNull(raw);
    if (n === null || n < 0) return { present: true, value: null };
    return { present: true, value: n };
  }
  const fMin   = ruleField('min_advance_minutes');
  const fDays  = ruleField('max_advance_days');
  const fDay   = ruleField('max_per_user_per_day');
  const fWeek  = ruleField('max_per_user_per_week');
  const fMonth = ruleField('max_per_user_per_month');
  const fPre   = ruleField('pre_end_notify_minutes');
  const fGrace = ruleField('grace_period_minutes');

  await execute(
    'UPDATE `facilities` SET ' +
    '  name                       = COALESCE(?, name), ' +
    '  type                       = COALESCE(?, type), ' +
    '  floor_id                   = COALESCE(?, floor_id), ' +
    '  capacity                   = COALESCE(?, capacity), ' +
    '  offline_capacity           = COALESCE(?, offline_capacity), ' +
    '  min_advance_minutes        = ' + (fMin.present   ? '?' : 'min_advance_minutes')    + ', ' +
    '  max_advance_days           = ' + (fDays.present  ? '?' : 'max_advance_days')       + ', ' +
    '  max_per_user_per_day       = ' + (fDay.present   ? '?' : 'max_per_user_per_day')   + ', ' +
    '  max_per_user_per_week      = ' + (fWeek.present  ? '?' : 'max_per_user_per_week')  + ', ' +
    '  max_per_user_per_month     = ' + (fMonth.present ? '?' : 'max_per_user_per_month') + ', ' +
    '  pre_end_notify_minutes     = ' + (fPre.present   ? '?' : 'pre_end_notify_minutes')   + ', ' +
    '  grace_period_minutes       = ' + (fGrace.present ? '?' : 'grace_period_minutes')    + ', ' +
    '  description                = COALESCE(?, description), ' +
    '  terms_and_conditions       = COALESCE(?, terms_and_conditions), ' +
    '  image_url                  = COALESCE(?, image_url), ' +
    '  layout_json                = ' + (hasLayout ? '?' : 'layout_json') + ', ' +
    '  requires_approval          = COALESCE(?, requires_approval), ' +
    '  shared_booking             = COALESCE(?, shared_booking), ' +
    '  facility_approver_user_id  = ' + (hasApprover ? '?' : 'facility_approver_user_id') + ', ' +
    '  status                     = COALESCE(?, status) ' +
    'WHERE id = ?',
    [
      b.name || null, b.type || null, intOrNull(b.floor_id), intOrNull(b.capacity),
      intOrNull(b.offline_capacity),
      ...(fMin.present   ? [fMin.value]   : []),
      ...(fDays.present  ? [fDays.value]  : []),
      ...(fDay.present   ? [fDay.value]   : []),
      ...(fWeek.present  ? [fWeek.value]  : []),
      ...(fMonth.present ? [fMonth.value] : []),
      ...(fPre.present   ? [fPre.value]   : []),
      ...(fGrace.present ? [fGrace.value] : []),
      b.description || null, b.terms_and_conditions || null, b.image_url || null,
      ...(hasLayout ? [layoutVal] : []),
      intOrNull(b.requires_approval), sharedVal,
      ...(hasApprover ? [newApprover] : []),
      intOrNull(b.status), id,
    ]
  );
  return ok(res, null, 'Facility updated');
});

exports.remove = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid id', 400);
  const r = await assertOwnership(req, 'facilities', id);
  if (!r.ok) return fail(res, r.msg, r.status);
  await execute('UPDATE `facilities` SET trash = 1 WHERE id = ?', [id]);
  return ok(res, null, 'Facility deleted');
});

// Nested: operating hours

exports.replaceHours = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid facility id', 400);
  const r = await assertOwnership(req, 'facilities', id);
  if (!r.ok) return fail(res, r.msg, r.status);

  const hours = Array.isArray(req.body && req.body.hours) ? req.body.hours : [];
  for (const h of hours) {
    const dow = intOrNull(h.day_of_week);
    if (dow === null || dow < 0 || dow > 6) {
      return fail(res, 'day_of_week must be 0-6 for every row', 422);
    }
    if (!h.open_time || !h.close_time) {
      return fail(res, 'open_time and close_time are required for every row', 422);
    }
    // BUG-05 fix: close_time must be strictly later than open_time. A
    // close < open row would silently invert the operating window and let
    // all day-time bookings slip through the hours-guard check.
    if (String(h.close_time) <= String(h.open_time)) {
      return fail(res, 'close_time must be after open_time for every row', 422);
    }
    // Slot size sanity — must be positive (0 would divide-by-zero in the
    // slot-grid alignment check downstream).
    const slot = intOrNull(h.slot_minutes);
    if (slot !== null && slot <= 0) {
      return fail(res, 'slot_minutes must be greater than zero', 422);
    }
  }

  await withTransaction(async function (conn) {
    await conn.execute('DELETE FROM `facility_operating_hours` WHERE facility_id = ?', [id]);
    for (const h of hours) {
      await conn.execute(
        'INSERT INTO `facility_operating_hours` (facility_id, day_of_week, open_time, close_time, slot_minutes) ' +
        'VALUES (?, ?, ?, ?, ?)',
        [
          id, intOrNull(h.day_of_week), h.open_time, h.close_time,
          intOrNull(h.slot_minutes) || 30,
        ]
      );
    }
  });
  return ok(res, null, 'Operating hours saved');
});

exports.listHours = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid facility id', 400);
  const r = await assertOwnership(req, 'facilities', id);
  if (!r.ok) return fail(res, r.msg, r.status);
  const rows = await query(
    'SELECT id, day_of_week, open_time, close_time, slot_minutes ' +
    '  FROM `facility_operating_hours` WHERE facility_id = ? ORDER BY day_of_week, open_time',
    [id]
  );
  return ok(res, rows);
});

exports._loadChain = loadChain;

// F09 - Chair delete guard.
// GET /api/facilities/:id/chair-bookings?chair_id=C-03
// Counts active future bookings holding the chair. Uses the booking_desks
// junction table (migration 053) — a plain `=` match now works instead of
// the old FIND_IN_SET on the legacy comma-string column.
exports.chairBookings = asyncHandler(async function (req, res) {
  const id = intOrNull(req.params.id);
  if (id === null) return fail(res, 'Invalid id', 400);
  const chairId = String(req.query.chair_id || '').trim();
  if (!chairId) return fail(res, 'chair_id is required', 422);

  const r = await assertOwnership(req, 'facilities', id);
  if (!r.ok) return fail(res, r.msg, r.status);

  const rows = await query(
    'SELECT COUNT(*) AS cnt ' +
    '  FROM `booking_desks` bd ' +
    '  INNER JOIN `bookings` b ON b.id = bd.booking_id ' +
    ' WHERE b.facility_id = ? AND b.trash = 0 ' +
    "   AND b.status IN ('pending','approved') " +
    '   AND b.end_at > NOW() ' +
    '   AND bd.desk_id = ?',
    [id, chairId]
  );
  return ok(res, { count: Number(rows[0]?.cnt || 0), chair_id: chairId });
});

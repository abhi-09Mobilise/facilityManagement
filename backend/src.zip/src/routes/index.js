// Top-level router. Each module owns its own routes file + role guards.

const express = require('express');
const router = express.Router();

router.use('/auth', require('../modules/auth/auth.routes'));

// Super-admin owned
router.use('/tenants', require('../modules/tenants/tenants.routes'));
router.use('/lookups', require('../modules/lookups/lookups.routes'));

// Tenant-admin owned (super_admin can target any tenant)
router.use('/organisations',      require('../modules/organisations/organisations.routes'));
router.use('/buildings',          require('../modules/buildings/buildings.routes'));
router.use('/users',              require('../modules/users/users.routes'));
router.use('/sites',              require('../modules/sites/sites.routes'));
router.use('/floors',             require('../modules/floors/floors.routes'));
router.use('/facilities',         require('../modules/facilities/facilities.routes'));
router.use('/departments',        require('../modules/departments/departments.routes'));
router.use('/meal-times',         require('../modules/mealTimes/mealTimes.routes'));
router.use('/pantries',           require('../modules/pantries/pantries.routes'));  // F06

// Bookings (employee-driven) + approvals inbox
router.use('/bookings',  require('../modules/bookings/bookings.routes'));
router.use('/approvals', require('../modules/approvals/approvals.routes'));

// Floor-plan auto-detection (admin only; proxies to Python microservice)
router.use('/floor-scan', require('../modules/floorScan/floorScan.routes'));

// Image uploads (admin only; proxies to Azure Blob sidecar)
router.use('/uploads', require('../modules/uploads/uploads.routes'));

// Cron-driven side jobs (gated by CRON_SECRET, no user auth)
router.use('/cron', require('../modules/cron/cron.routes'));

// Admin dashboards (super_admin + tenant_admin)
router.use('/dashboards', require('../modules/dashboards/dashboards.routes'));

// Configurable RBAC — roles & permissions matrix
router.use('/permissions', require('../modules/permissions/permissions.routes'));

router.get('/health', function (_req, res) {
  return res.json({ status: true, msg: 'ok' });
});

module.exports = router;
